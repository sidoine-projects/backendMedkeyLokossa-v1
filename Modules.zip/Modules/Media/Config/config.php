<?php

return [
    'name' => 'Media',
    'prefixe_table' => env('PREFIXE_TABLE', 'am_'),
];
