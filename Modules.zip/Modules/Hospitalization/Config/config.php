<?php

return [
    'name' => 'Hospitalization',
];
