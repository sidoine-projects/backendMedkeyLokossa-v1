<?php

return [
    /*
      |--------------------------------------------------------------------------
      | Lignes de langue de Notifier
      |--------------------------------------------------------------------------
     */

    'notifier' => [
        'lien_temporaire' => [
            'texte_1' => "Veuillez trouver ci-dessous, le lien de confirmation de votre adresse courriel",
            'texte_2' => "Ce lien est valide pendant :duree_lien_temp",
            'texte_3' => "Cliquez ici pour confirmer",
        ]
    ]
];
