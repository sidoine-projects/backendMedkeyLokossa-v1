<style type="text/css">
    span{
        font-weight: bold;
    }
</style>
<body>
    <p>{{ __('Bonjour') }},</p>
    <p>
        Code : {{ $tel_mobile_code }}.
    </p>
</body>