<?php

return [
    'name' => 'Acl',
    'prefixe_table' => env('PREFIXE_TABLE', 'am_'),
    
    'media_collection_name' => 'user',
    'media_disk' => 'disk_user',    //Voir config/filesystem.php
];
