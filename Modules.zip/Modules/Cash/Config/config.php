<?php

return [
    'name' => 'Cash'
];
