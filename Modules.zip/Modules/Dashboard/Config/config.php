<?php

return [
    'name' => 'Dashboard',
    'prefixe_table' => env('PREFIXE_TABLE', 'am_'),
];
