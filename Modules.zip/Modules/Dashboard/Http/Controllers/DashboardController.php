<?php

namespace Modules\Dashboard\Http\Controllers;

use App\Http\Controllers\Api\V1\ApiController;

class DashboardController extends ApiController
{
    
}
