<?php

return [
    'name' => 'Administration'
];
