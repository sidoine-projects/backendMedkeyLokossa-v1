<?php

return [
    'name' => 'Annuaire',
    'prefixe_table' => env('PREFIXE_TABLE', 'at_'),
];
