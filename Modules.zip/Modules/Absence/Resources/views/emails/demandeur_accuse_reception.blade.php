{{-- @TODO : Bien formater cette vue --}}

<h1>Bonjour {{ $demandeur->user->full_name }}</h1>

<p>
    Ce courriel est pour vous confirmer que nous avons bien reçu votre demande.
</p>
<hr>
Équipe SIGAL
