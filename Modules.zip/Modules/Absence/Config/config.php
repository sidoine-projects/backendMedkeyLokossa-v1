<?php

return [
    'name' => 'Absence',
    'prefixe_table' => env('PREFIXE_TABLE', 'at_'),
];
