<?php

namespace App\Http\Controllers;

use GuzzleHttp\Client;
use Illuminate\Http\Request;
use PatricPoba\MtnMomo\MtnCollection;
use PatricPoba\MtnMomo\MtnConfig;
use App\Models\Payement;
use App\Models\ModePayement;
use App\Models\Momo;
use App\Models\Fedapay;
use App\Models\Espece;
use Illuminate\Support\Facades\DB;
use Kkiapay\Kkiapay;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;


class PayementController extends Controller
{

    public function index()
    {
        return view('momo');
    }


    public function store(Request $request)
    {
        // Validation des données entrantes
        // DB::statement('ALTER TABLE payements AUTO_INCREMENT = 1;');

        $validatedData = $request->validate([
            'patient_id' => 'required|integer',
            'mode_payement_id' => 'required|integer',
        ]);

        $data = Payement::create([
            'is_synced' => 0, // Marquer comme non synchronisé
            'patient_id' => $validatedData['patient_id'],
            'mode_payement_id' => $validatedData['mode_payement_id'],
        ]);

        $payementId = $data->id;

        // Réponse JSON avec les données du nouveau paiement
        return response()->json([
            'success' => true,
            'data' => $payementId,
            'message' => 'Paiement créé avec succès.'
        ], 201);
    }


    public function show($id)
    {
        // Recherche du patient
        $payement = Payement::find($id);

        // Vérification si le patient existe
        if (!$payement) {

            return response()->json([
                'success' => false,
                'message' => 'Patient introuvable.'
            ], 404);

        }


        // Réponse JSON avec les données du patient
        return response()->json([
            'success' => true,
            'data' => $payement
        ]);
    }


    public function especePayer($payementId, Request $request)
    {
        // Validation des données entrantes
        $validatedData = $request->validate([
            
            'mode_payements_id' => 'required|integer',
            'montant' => 'required|integer',
        ]);

        $data = Espece::create([
            'is_synced' => 0, // Marquer comme non synchronisé
            'mode_payements_id' => $validatedData['mode_payements_id'],
            'payement_id' =>  $payementId,
            'montant' => $validatedData['montant']
        ]);

        // Réponse JSON avec les données du nouveau paiement
        return response()->json([
            'success' => true,
            'data' => $data,
            'message' => 'Paiement créé avec succès.'
        ], 201);

        
    }


    public function mtn($payementId, Request $request)
    {
        $client = new Client([
            'base_uri' => 'https://sandbox.momodeveloper.mtn.com',
            'verify' => false, // Ignorer la vérification du certificat SSL
        ]);

        $mtn = "mtn";
        // $objet = $request->objet; // L'objet
        $objet = 'je suis objet'; // L'objet
        $prenom = $request->prenom; // L'objet

        $mode_payements_id =  $request->mode_payements_id; // Quand on definit une constante, au niveau de la vue, c'est toujours la meme valeur de la constante qui est appelé
        $nom = $request->nom;
        //  $prix = $request->prix; // montant
        $montant = $request->montant; // montant
        // $prenom = $request->objet;
        $numero = $request->telephone;
        // $numero = $request->telephone;




        $config = new MtnConfig([
            // mandatory credentials
            'baseUrl' => 'https://sandbox.momodeveloper.mtn.com',
            'verify' => false, // Ignorer la vérification du certificat SSL
            'currency' => 'EUR',
            'targetEnvironment' => 'sandbox',

            // collection credentials
            "collectionApiSecret" => 'a47f23bfa8ae429da131c52c6d9f29d2', //API key
            "collectionPrimaryKey" => '5ed6ba072ef4458badb00244a587cf3f', //ocpim
            "collectionUserId" => '765f2145-bb2f-4caf-81b9-6ecdb2ecf32b', // Api user
            // "collectionApiSecret" => '', //API key
            // "collectionPrimaryKey" => '', //ocpim
            // "collectionUserId" => '', // Api user
        ]);

        $collection = new MtnCollection($config);
        // $indice = '225';
        // $params = [
        //     "mobileNumber" => '2250586953562', //$indice.  $numero,  // "mobileNumber"      => $indice. '0586953562',
        //     "amount" => '100', //$prix,
        //     "externalId" => '774747234',
        //     "payerMessage" => 'some note',
        //     "payeeNote" => '1212',
        // ];
        //////////////////////////////////////////////////////////////////////////////
        $params = [
            "mobileNumber" => $numero, //'22962032158',//$indice.  $numero
            "amount" => $montant, //'10', //$prix,
            "externalId" => '774747234',
            "payerMessage" => $objet,
            "payeeNote" => '1212',
        ];
        ////////////////////////////////////////////////////////////////////////////////////
        //dd($collection);
        $transactionId = $collection->requestToPay($params);


        // echo $transactionId;     
        // echo $indice;

        $transaction = $collection->getTransaction($transactionId); // obtenir les donnees de la transaction

        //   dd($transaction);
        //dd(  $transaction );
        $ion = $transaction->financialTransactionId;    // l'id de la transaction
        //  $ion = $transaction->getFinancialTransactionId();

        // dd($ion );

        $ion1 = $transaction->externalId;
        $ion2 = $transaction->amount;
        $ion3 = $transaction->payer;
        //  $ion4 = $transaction->payer;
        $ion5 = $transaction->currency;
        $ion6 = $transaction->status;
        //  $ion6 = "PENDING";
        //  $ion7 = $numero;
        //  $ion8 = $nom;
        //  $ion9 = $objet;
        //  $ion10 = $mode_payements_id;


        // $ion6 = "PENDING";

        if ($ion6 === 'SUCCESSFUL') {

            $momo = Momo::create([

                'mode_payements_id' => $mode_payements_id,
                'payement_id' => $payementId,
                'nom' => $nom,
                'prenom' => $prenom,
                'telephone' => $numero,
                'montant' =>  $montant,
                'transaction_id' => $ion,
                'statut' =>  $ion6,

            ]);
        }

        return response()->json([
            'message' => 'payement créée avec succès !!!',
            'transaction' => $momo,
        ]);
    }




    public function mtnretour(Request $request)
    {
        $mtn = "mtn";
        $transactionId = $request->transactionId;

        $objet = $request->objet;
        $numero = $request->numero;
        $prix = $request->prix;
        $nom = $request->nom;

        $config = new MtnConfig([
            // mandatory credentials
            'baseUrl' => 'https://sandbox.momodeveloper.mtn.com',
            'currency' => 'EUR',
            'targetEnvironment' => 'sandbox',

            // collection credentials
            "collectionApiSecret" => 'a47f23bfa8ae429da131c52c6d9f29d2', //API key
            "collectionPrimaryKey" => '5ed6ba072ef4458badb00244a587cf3f', //ocpim
            "collectionUserId" => '765f2145-bb2f-4caf-81b9-6ecdb2ecf32b', // Api user
        ]);

        $collection = new MtnCollection($config);

        //55f8fb98-3917-4202-944b-b3fc3b5afb64

        $transaction = $collection->getTransaction($transactionId);

        // var_dump($transaction);

        // $ion1 =$transaction->externalId;
        // $ion2 =$transaction->amount;
        // $ion3 =$transaction->payer;
        // // $ion4 = $transaction->payer->payerpartyId;
        // $ion5 =$transaction->currency;
        $ion6 = $transaction->status;
        // echo $transacstaus6;

        // base de donnée
        // if($ion6 == "SUCCESSFUL"){
        //     $payer = new Payer;

        //     $payer->reseau= $mtn;
        //     $payer->volume_sms=  $objet;
        //     $payer->trans=  $transactionId;
        //     $payer->status=  $ion6;
        //     $payer->numero=  $numero;
        //     $payer->prix=  $prix;
        //     $payer->nom= $nom;
        //     $payer->save();

        // }
        // if($ion6 == "FAILED"){
        //     $payers = new Payer;

        //     $payers->reseau= $mtn;
        //     $payers->volume_sms= $objet;
        //     $payers->trans=  $transactionId;
        //     $payers->status=  $ion6;
        //     $payers->numero=  $numero;
        //     $payers->prix=  $prix;
        //     $payers->nom= $nom;
        //     $payers->save();

        // }

        return view('lastpart', [
            'mtn' => $mtn,
            'ion6' => $ion6,
            'transactionId' => $transactionId,
            'objet' => $objet,
            'numero' => $numero,
            'prix' => $prix,
            'nom' => $nom,
        ]);
    }


    public function fedapay(Request $request, $payementId)
    {

        $fedapay = Fedapay::create([

            'mode_payements_id' => $request->mode_payements_id,
            'payement_id' => $payementId,
            'nom' => $request->nom,
            'prenom' => $request->prenom,
            'telephone' => $request->telephone,
            'montant' =>  $request->montant,
            'transaction_id' => $request->transaction_id,
            'statut' => $request->statut,

        ]);

        return response()->json([
            'message' => 'payement créée avec succès !!!',
            'data' =>  $fedapay,
        ]);
    }


    public function kkiapay($transaction_id)
    {

        $public_key = "d9da5d50d3a311edb532ad421d393c9e";
        $private_key = "tpk_d9da8461d3a311edb532ad421d393c9e";
        $secret = "tsk_d9da8462d3a311edb532ad421d393c9e";
        $sandbox = true;

        $kkiapay = new  \Kkiapay\Kkiapay(
            $public_key,
            $private_key,
            $secret,
            $sandbox
        );




        $retour =  $kkiapay->verifyTransaction($transaction_id);

        return response()->json([
            'message' => 'payement créée avec succès !!!',
            'data' =>   $retour,
        ]);
    }




    public function synchroniserPayements()
    {

        // Récupérer l'utilisateur authentifié

        $accessToken = config('app.API_ACCESS_TOKEN');

        $url = 'http://www.google.com';

        $timeout = 5;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Vérifier le statut de la connexion Internet

        if ($httpCode == 200) {

            // $payementsNonSync = payement::where('is_synced', 0)->get();

            $payementsNonSync = Payement::where('is_synced', 0)->get();


            $headers = [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $accessToken,
            ];


            foreach ($payementsNonSync as $payement) {


                $response =  Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/payement/' . $payement->id);

                if ( $response->ok() ) {

                    Log::info('Enregistrement non effectué ');

                }else{

                    
                    Log::info('Enregistrement non trouvé ');

                    $data = $payement->toArray();

                    $response = Http::withHeaders($headers)->post('https://api-medpay.akasigroup.net/api/payement', $data);
                    // Log::info($response->json());
         
                    Log::info('Enregistrement effectué ');
                    
                }


                if( $response->successful() ) {
                    // Mettre à jour le statut de synchronisation du payement en local
                    $payement->is_synced = 1;
                    $payement->save();

                    Log::info('payement synchronisé avec succès. id : ' . $payement->id);

                } else {

                    Log::error('Erreur lors de la synchronisation de l\'payement. id : ' . $payement->id . ' - Réponse API : ' . json_encode($response->json()));
                }

            }


        } else {
            Log::error('Internet connection is not available.');
        }
    }


    public function synchroniserEspeces()
    {
        // Récupérer l'utilisateur authentifié

        $accessToken = config('app.API_ACCESS_TOKEN');

        $url = 'http://www.google.com';

        $timeout = 5;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Vérifier le statut de la connexion Internet

        if ($httpCode == 200) {

            $especesNonSync = Espece::where('is_synced', 0)->get();


            $headers = [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $accessToken,
            ];


            foreach ($especesNonSync as $espece) {

                $response =  Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/espece/' . $espece->id);

                if (!$response->successful()) {

                    $data = $espece->toArray();

                    $response = Http::withHeaders($headers)->post('https://api-medpay.akasigroup.net/api/especepayement/' . $espece->payement_id, $data);


                    Log::info('Enregistrement effectué ');
                } 

                if ($response->successful()) {
                    // Mettre à jour le statut de synchronisation du payement en local
                    $espece->is_synced = 1;
                    $espece->save();
                    Log::info('espece synchronisé avec succès. id : ' . $espece->id);
                } else {

                    Log::error('Erreur lors de la synchronisation de l\'espece. id : ' . $espece->id . ' - Réponse API : ' . $response->json());
                }
            }


        } else {
            Log::error('Internet connection is not available.');
        }
    }





}
