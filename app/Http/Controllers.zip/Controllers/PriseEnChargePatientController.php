<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\PriseEnChargePatient;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;


class PriseEnChargePatientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $user = auth()->user();
        $centreId = $user->idcentre;

        $roleId = $user->role_id;
        // Récupérer tous les enregistrements PriseEnChargePatient
        // $priseEnChargePatients = PriseEnChargePatient::all();


        $priseEnChargePatients = PriseEnChargePatient::orderBy('priseenchargepatient.created_at', 'desc')
            ->join('users', 'priseenchargepatient.user_id', '=', 'users.id')
            ->join('centresanitaires', 'users.idcentre', '=', 'centresanitaires.id')
            ->where('users.idcentre', $centreId)
            ->where('priseenchargepatient.deleted_at', 0)
            ->get();

        if ($roleId == 10 || $roleId == 1) {

            $priseEnChargePatients = PriseEnChargePatient::orderBy('created_at', 'desc')
                ->where('deleted_at', 0)
                ->get();
        }


        // $priseEnChargePatients = Patient::with('patient:id,nom,prenom');

        return response()->json([
            'success' => true,
            'data' => $priseEnChargePatients,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */


    public function store(Request $request)
    {

        $validatedData = $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'assurance_id' => 'required|exists:assurances,id',
            'pourcentage' => 'required|numeric',
            'statut' => 'required|in:public,privé',
            'datedebut' => 'required|date',
            'compagnie_d_assurance_id' => 'required|integer',
            'datefin' => 'required|date',
            'observation' => 'nullable|string',
            'numero_assurance' => 'required|string',
        ]);

        // $userId = auth()->user()->id;
        $userId = $request->user_id ? $request->user_id : auth()->user()->id;


        // Création d'une nouvelle instance de PriseEnChargePatient
        $priseEnChargePatient = new PriseEnChargePatient();
        $priseEnChargePatient->is_synced = 0;
        $priseEnChargePatient->user_id = $userId;
        $priseEnChargePatient->patient_id = $validatedData['patient_id'];
        $priseEnChargePatient->assurance_id = $validatedData['assurance_id'];
        $priseEnChargePatient->pourcentage = $validatedData['pourcentage'];
        $priseEnChargePatient->statut = $validatedData['statut'];
        $priseEnChargePatient->datedebut = $validatedData['datedebut'];
        $priseEnChargePatient->compagnie_d_assurance_id = $validatedData['compagnie_d_assurance_id'];
        $priseEnChargePatient->datefin = $validatedData['datefin'];
        $priseEnChargePatient->observation = $validatedData['observation'];
        $priseEnChargePatient->numero_assurance = $validatedData['numero_assurance'];
        $priseEnChargePatient->deleted_at = $request->input('deleted_at', 0);

        // Enregistrement de la prise en charge patient dans la base de données
        $priseEnChargePatient->save();

        // Réponse JSON avec les données de la prise en charge nouvellement créée
        return response()->json([
            'success' => true,
            'data' => $priseEnChargePatient,
            'message' => 'Prise en charge enregistrée avec succès.'
        ], 201);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $priseEnChargePatient = PriseEnChargePatient::findOrFail($id);

        return response()->json([
            'success' => true,
            'data' => $priseEnChargePatient,
        ]);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            $validatedData = $request->validate([
                'patient_id' => 'required|exists:patients,id',
                'assurance_id' => 'required|exists:assurances,id',
                'pourcentage' => 'required|numeric',
                'statut' => 'required|in:public,privé',
                'datedebut' => 'required|date',
                'compagnie_d_assurance_id' => 'required|integer',
                'datefin' => 'required|date',
                'observation' => 'nullable|string',
                'numero_assurance' => 'required|string',
            ]);

            $userId = $request->user_id ? $request->user_id : auth()->user()->id;


            // Recherche de la prise en charge à mettre à jour
            $priseEnChargePatient = PriseEnChargePatient::findOrFail($id);

            // Mise à jour des champs
            $priseEnChargePatient->is_synced = 0;
            $priseEnChargePatient->user_id = $userId;
            $priseEnChargePatient->patient_id = $validatedData['patient_id'];
            $priseEnChargePatient->assurance_id = $validatedData['assurance_id'];
            $priseEnChargePatient->pourcentage = $validatedData['pourcentage'];
            $priseEnChargePatient->statut = $validatedData['statut'];
            $priseEnChargePatient->datedebut = $validatedData['datedebut'];
            $priseEnChargePatient->compagnie_d_assurance_id = $validatedData['compagnie_d_assurance_id'];
            $priseEnChargePatient->datefin = $validatedData['datefin'];
            $priseEnChargePatient->observation = $validatedData['observation'];
            $priseEnChargePatient->numero_assurance = $validatedData['numero_assurance'];
            $priseEnChargePatient->deleted_at = $request->input('deleted_at', 0);

            // Enregistrement des modifications dans la base de données
            $priseEnChargePatient->save();

            // Réponse JSON avec les données de la prise en charge mise à jour
            return response()->json([
                'success' => true,
                'data' => $priseEnChargePatient,
                'message' => 'Prise en charge mise à jour avec succès.'
            ], 200);
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Une erreur est survenue lors de la mise à jour de la prise en charge.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Une erreur est survenue lors de la mise à jour de la prise en charge.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }



    // public function update(Request $request, $id)
    // {
    //     $validatedData = $request->validate([
    //         'patient_id' => 'exists:patients,id',
    //         'assurance_id' => 'exists:assurances,id',
    //         'pourcentage' => 'numeric',
    //         'statut' => 'in:public,privé',
    //         'datedebut' => 'date',
    //         'datefin' => 'date',
    //         'observation' => 'nullable|string',
    //         'compagnie_d_assurance_id' => 'required|integer',
    //         'numero_assurance' => 'string',

    //     ]);

    //     $priseEnChargePatient = PriseEnChargePatient::find($id);
    //     $priseEnChargePatient->update($validatedData);

    //     return response()->json([
    //         'success' => true,
    //         'data' => $priseEnChargePatient,
    //     ]);
    // }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $priseEnChargePatient = PriseEnChargePatient::findOrFail($id);
        $priseEnChargePatient->update(['is_synced' => 0]);
        $priseEnChargePatient->update(['deleted_at' => 1]);

        return response()->json([
            'success' => true,
            'message' => 'Enregistrement PriseEnChargePatient supprimé avec succès.',
        ]);
    }

    public function getAssurancePatient($patientId)
    {
        $priseEnChargePatient = PriseEnChargePatient::where('patient_id', '=', $patientId)
            ->with('assurance')
            ->first();

        // if (!$priseEnChargePatient) {
        //     return response()->json([
        //         'success' => false,
        //         'message' => 'Aucune prise en charge trouvée pour ce patient.',
        //     ], 404);
        // }
        // if (!$priseEnChargePatient) {
        //     return response()->json([
        //         'success' => false,
        //         'data' => [
        //             'assurance_nom' => 'aucune assurance',  // Valeur par défaut pour l'assurance_nom
        //             'pourcentage_assurance' => 0,  // Valeur par défaut pour le pourcentage_assurance
        //         ],
        //         'message' => 'Aucune prise en charge trouvée pour ce patient.',
        //     ]);
        // }

        if ($priseEnChargePatient) {
            # code...
            $assuranceNom = $priseEnChargePatient->assurance->nom;
            $pourcentageAssurance = $priseEnChargePatient->pourcentage;
            $numero_assurance = $priseEnChargePatient->numero_assurance;
        } else {
            # code...
            $assuranceNom = null;
            $pourcentageAssurance = null;
            $numero_assurance = null;
        }


        return response()->json([
            'success' => true,
            'data' => [
                'assurance_nom' => $assuranceNom,
                'pourcentage_assurance' => $pourcentageAssurance,
                'numero_assurance' => $numero_assurance,
            ],
        ]);
    }

    public function synchroniserPriseEnChargePatients()
    {

        // Récupérer l'utilisateur authentifié

        $accessToken = config('app.API_ACCESS_TOKEN');

        $url = 'http://www.google.com';

        $timeout = 5;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Vérifier le statut de la connexion Internet

        if ($httpCode == 200) {



            // $patientsNonSync = patient::where('is_synced', 0)->get();
            $priseenchargepatientsNonSync = PriseEnChargePatient::where('is_synced', 0)->get();


            $headers = [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $accessToken,
            ];


            foreach ($priseenchargepatientsNonSync as $priseenchargepatients) {


                // $response = Http::get('https://api-medpay.akasigroup.net/api/patient/' . $patient->id);

                $response =  Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/priseencharges/' . $priseenchargepatients->id);

                if ($response->successful()) {

                    Log::info('enregistrement trouvé ');

                    // Log::info($response->json());


                    // Si le patient existe en ligne, mettre à jour les informations

                    $response =  Http::withHeaders($headers)->put('https://api-medpay.akasigroup.net/api/priseencharges/' . $priseenchargepatients->id, $priseenchargepatients->toArray());

                    Log::info('Modification effectué ');
                    Log::info('Assurance patient Modifiée : ' . json_encode($response->json()));
                } else {

                    // Sinon, si le patient est nouveau (n'a jamais été synchronisé), l'envoyer en ligne

                    $data = $priseenchargepatients->toArray();

                    $response = Http::withHeaders($headers)->post('https://api-medpay.akasigroup.net/api/priseencharges', $data);

                    Log::info('Assurance patient  : ' . json_encode($response->json()));
                }

                if ($response->successful()) {
                    // Mettre à jour le statut de synchronisation du patient en local
                    $priseenchargepatients->is_synced = 1;
                    $priseenchargepatients->save();
                    Log::info('Assurance patient synchronisé avec succès. id : ' . $priseenchargepatients->id);
                } else {

                    Log::error('Erreur lors de la synchronisation de l\'patient. id : ' . $priseenchargepatients->id);
                }
            }


            $priseenchargepatientsNonSyncdeleted = PriseEnChargePatient::where('is_synced', 0)->where('deleted_at', 1)->get();

            if ($priseenchargepatientsNonSyncdeleted) {

                foreach ($priseenchargepatientsNonSyncdeleted as   $priseenchargepatientidSupprime) {
                    // Vérifier si l'ID existe en ligne avant de le supprimer

                    $response = Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/priseencharges/' .  $priseenchargepatientidSupprime->id);



                    if ($response->successful()) {
                        // Supprimer le patient en ligne
                        $deleteResponse = Http::withHeaders($headers)->delete('https://api-medpay.akasigroup.net/api/priseencharges/' . $priseenchargepatientidSupprime->id);
                        Log::info('Patient récupéré  effectué ');

                        if ($deleteResponse->successful()) {
                            $priseenchargepatientidSupprime->is_synced = 1;
                            $priseenchargepatientidSupprime->save();
                            Log::info('Assurance patient supprimé en ligne avec succès. ID : ' . $priseenchargepatientidSupprime->id);
                            // Supprimer l'ID de la liste après la suppression réussie

                        } else {
                            Log::error('Erreur lors de la suppression en ligne de indigence patient. ID : ' . $priseenchargepatientidSupprime->id);
                        }
                    } else {
                        Log::warning('Indigence Patient non trouvé en ligne. ID : ' . $priseenchargepatientidSupprime);
                    }
                }
            }
        } else {
            Log::error('Internet connection is not available.');
        }
    }
}
