<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AffecterTerminal;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;

class TerminalAffectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        // $affecterterminal = AffecterTerminal::latest()->get();
        // return response()->json([
        //     'success' => true,
        //     'data' => $affecterterminal,
        //     'message' => 'Liste des terminaux affectés.'
        // ]);
        // Récupérer l'utilisateur authentifié

        $user = auth()->user();

        // Récupérer l'ID du centre de l'utilisateur
        $centreId = $user->idcentre;
        $roleId = $user->role_id;


        $affecterterminal = AffecterTerminal::where('idcentre', $centreId)
            ->where('deleted_at', 0)
            ->latest()->get();


        if ( $roleId == 10 || $roleId == 1) { // Vérifie si l'utilisateur a le rôle super_admin
            // $allUsers = User::all(); // Récupère tous les utilisateurs
            $affecterterminal = AffecterTerminal::where('deleted_at', 0)->orderBy('created_at', 'desc')->get();
        }

        return response()->json([
            'success' => true,
            'data' => $affecterterminal,
            'message' => 'Liste des terminaux affectés associés au centre.'
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Récupérer l'utilisateur authentifié
        // $user = auth()->user();
        $userId = $request->user_id ? $request->user_id : auth()->user()->id;
        $user = User::find($userId);
        //
        $request->validate([
            'user_id' => 'required|integer',
            'terminal_id' => 'required|integer',


            // Ajoutez d'autres règles de validation pour les autres champs si nécessaire
        ]);
        // $user = auth()->user();
        $terminal = new AffecterTerminal();
        $terminal->is_synced = 0;
        $terminal->user_id = $request->input('user_id');
        $terminal->idcentre = $user->idcentre;
        $terminal->terminal_id = $request->input('terminal_id');
        $terminal->deleted_at = $request->input('deleted_at', 0);
        // Enregistrez le pays dans la base de données
        $terminal->save();

        return response()->json([
            'success' => true,
            'data' => $terminal,
            'message' => 'Le terminal a été créé avec succès.'
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $terminal = AffecterTerminal::find($id);

        if (!$terminal) {
            return response()->json([
                'success' => false,
                'message' => "L'utilisateur n'est pas associé à un Terminal.",
            ], 400);
        }


        return response()->json([
            'success' => true,
            'data' => $terminal,
            'message' => 'Détails du terminal.'
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $terminal = AffecterTerminal::find($id);

        if (!$terminal) {
            return response()->json([
                'success' => false,
                'message' => "L'utilisateur n'est pas associé à un Terminal.",
            ], 400);
        }


        // Valider les données du formulaire
        $validatedData = $request->validate([
            'user_id' => 'required|integer',
            'terminal_id' => 'required|integer',
            // Ajoutez ici les autres règles de validation pour les autres champs du modèle Pays
        ]);

        // Mettre à jour les propriétés du modèle Pays avec les données validées
        $terminal->is_synced = 0;
        $terminal->user_id = $validatedData['user_id'];
        $terminal->terminal_id = $validatedData['terminal_id'];
        $terminal->deleted_at = $request->input('deleted_at', 0);
        // Mettez à jour ici les autres propriétés du modèle Pays avec les données validées

        // Enregistrer les modifications dans la base de données
        $terminal->save();

        return response()->json([
            'success' => true,
            'data' => $terminal,
            'message' => 'Le terminal a été mis à jour avec succès.'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $terminal = AffecterTerminal::find($id);

        // Supprimer le pays de la base de données
        $terminal->update(['is_synced' => 0]);
        $terminal->update(['deleted_at' => 1]);
        // $terminal->delete();

        return response()->json([
            'success' => true,
            'message' => 'Terminal supprimé avec succès.'
        ]);
    }

    public function synchroniserAffectTerminals()
    {

        // Récupérer l'utilisateur authentifié

        $accessToken = config('app.API_ACCESS_TOKEN');

        $url = 'http://www.google.com';

        $timeout = 5;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Vérifier le statut de la connexion Internet

        if ($httpCode == 200) {



            // $patientsNonSync = patient::where('is_synced', 0)->get();
            $affectterminalsNonSync = AffecterTerminal::where('is_synced', 0)->get();


            $headers = [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $accessToken,
            ];


            foreach ($affectterminalsNonSync as $affectterminal) {


                // $response = Http::get('https://api-medpay.akasigroup.net/api/patient/' . $patient->id);

                $response =  Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/affectterminals/' . $affectterminal->id);

                if ($response->successful()) {

                    Log::info('enregistrement trouvé ');
                    // Log::info($response->json());


                    // Si le patient existe en ligne, mettre à jour les informations

                    $response =  Http::withHeaders($headers)->put('https://api-medpay.akasigroup.net/api/affectterminals/' . $affectterminal->id, $affectterminal->toArray());

                    Log::info('Modification effectué ');
                } else {

                    // Sinon, si le patient est nouveau (n'a jamais été synchronisé), l'envoyer en ligne

                    $data = $affectterminal->toArray();

                    $response = Http::withHeaders($headers)->post('https://api-medpay.akasigroup.net/api/affectterminals', $data);
                }

                if ($response->successful()) {
                    // Mettre à jour le statut de synchronisation du patient en local
                    $affectterminal->is_synced = 1;
                    $affectterminal->save();
                    Log::info('terminal synchronisé avec succès. id : ' . $affectterminal->id);
                } else {

                    Log::error('Erreur lors de la synchronisation du termianl. id : ' . $affectterminal->id . ' - Réponse API : ' . $response->json());
                }
            }


            $affectterminalsNonSyncdeleted = AffecterTerminal::where('is_synced', 0)->where('deleted_at', 1)->get();

            if ($affectterminalsNonSyncdeleted) {

                foreach ($affectterminalsNonSyncdeleted as  $affectterminalidSupprime) {
                    // Vérifier si l'ID existe en ligne avant de le supprimer

                    $response = Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/affectterminals/' . $affectterminalidSupprime->id);



                    if ($response->successful()) {
                        // Supprimer le patient en ligne
                        $deleteResponse = Http::withHeaders($headers)->delete('https://api-medpay.akasigroup.net/api/affectterminals/' . $affectterminalidSupprime->id);
                        Log::info('Terminal récupéré  effectué ');

                        if ($deleteResponse->successful()) {
                            $affectterminalidSupprime->is_synced = 1;
                            $affectterminalidSupprime->save();
                            Log::info('Terminal supprimé en ligne avec succès. ID : ' . $affectterminalidSupprime->id);
                            // Supprimer l'ID de la liste après la suppression réussie

                        } else {
                            Log::error('Erreur lors de la suppression en ligne du terminal. ID : ' . $affectterminalidSupprime->id);
                        }
                    } else {
                        Log::warning('Patient non trouvé en ligne. ID : ' . $affectterminalidSupprime);
                    }
                }
            }
        } else {
            Log::error('Internet connection is not available.');
        }
    }
}
