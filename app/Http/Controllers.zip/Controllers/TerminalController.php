<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Terminal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;

class TerminalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        // $terminal = Terminal::latest()->get();
        // return response()->json([
        //     'success' => true,
        //     'data' => $terminal,
        //     'message' => 'Liste des terminaux.'
        // ]);
        $user = auth()->user();

        $centreId = $user->idcentre;
        $roleId = $user->role_id;

        
        $getTerminal = Terminal::where('idcentre', $centreId)
            ->where('deleted_at', 0)
            ->latest()
            ->get(); // Filtre les terminaux par centre



        if ( $roleId == 10 || $roleId == 1) {  // Vérifie si l'utilisateur a le rôle super_admin


            $getTerminal = Terminal::where('deleted_at', 0)
            ->latest()
            ->get(); // Filtre les terminaux par centre


        }


        return response()->json([
            'success' => true,
            'data' => $getTerminal,
            'message' => 'Liste des terminaux.'
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // public function store(Request $request)
    // {

    //     $user = auth()->user();

    //     $centreId = $user->idcentre;
    //     //
    //     $request->validate([
    //         'nom' => 'required|string|max:255',
    //         'idcentre' => 'required|integer',
    //         'Description' => 'required|string|max:255',
    //         // Ajoutez d'autres règles de validation pour les autres champs si nécessaire
    //     ]);

    //     $terminal = new Terminal();
    //     $terminal->nom = $request->input('nom');
    //     $terminal->idcentre = $centreId;
    //     $terminal->Description = $request->input('Description');

    //     // Enregistrez le pays dans la base de données
    //     $terminal->save();

    //     return response()->json([
    //         'success' => true,
    //         'data' => $terminal,
    //         'message' => 'Le terminal a été créé avec succès.'
    //     ]);
    // }

    public function store(Request $request)
    {
        // Récupérer l'utilisateur authentifié
        // $user = auth()->user();
        $userId = $request->user_id ? $request->user_id : auth()->user()->id;
        $user = User::find($userId);


        // Si l'utilisateur n'est pas associé à un centre, retourner une réponse d'erreur
        if (!$user->idcentre) {
            return response()->json([
                'success' => false,
                'message' => "L'utilisateur n'est pas associé à un centre.",
            ], 400);
        }

        // Valider les données de la requête entrante
        $request->validate([
            'nom' => 'required|string|max:255',
            // Vous pouvez retirer la validation de 'idcentre' car il est défini à partir de l'utilisateur authentifié
            'Description' => 'required|string|max:255',
            // Ajoutez d'autres règles de validation pour les autres champs si nécessaire
        ]);

        // Créer une nouvelle instance de Terminal et remplir avec les données
        $terminal = new Terminal();

        $terminal->is_synced = 0;
        $terminal->nom = $request->input('nom');
        $terminal->idcentre = $user->idcentre; // Définir l'ID du centre à partir de l'utilisateur authentifié
        $terminal->Description = $request->input('Description');
        $terminal->deleted_at = $request->input('deleted_at', 0);

        // Enregistrer l'enregistrement du terminal dans la base de données
        $terminal->save();

        return response()->json([
            'success' => true,
            'data' => $terminal,
            'message' => 'Le terminal a été créé avec succès.',
        ]);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $terminal = Terminal::find($id);

         // Vérification si le patient existe
         if (!$terminal) {
            return response()->json([
                'success' => false,
                'message' => 'Terminal introuvable.'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $terminal
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function update(Request $request, $id)
    // {
    //     //
    //     $terminal = Terminal::find($id);
    //     $user = auth()->user();

    //     // Si l'utilisateur n'est pas associé à un centre, retourner une réponse d'erreur
    //     if (!$user->idcentre) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => "L'utilisateur n'est pas associé à un centre.",
    //         ], 400);
    //     }
    //     // Valider les données du formulaire
    //     $validatedData = $request->validate([
    //         'nom' => 'required|string|max:255',
    //         'Description' => 'required|string|max:255',
    //         // Ajoutez ici les autres règles de validation pour les autres champs du modèle Pays
    //     ]);

    //     // Mettre à jour les propriétés du modèle Pays avec les données validées
    //     $terminal->nom = $validatedData['nom'];
    //     $terminal->idcentre = $user->idcentre;
    //     $terminal->Description = $validatedData['Description'];
    //     // Mettez à jour ici les autres propriétés du modèle Pays avec les données validées

    //     // Enregistrer les modifications dans la base de données
    //     $terminal->save();

    //     return response()->json([
    //         'success' => true,
    //         'data' => $terminal,
    //         'message' => 'Le terminal a été mis à jour avec succès.'
    //     ]);
    // }

    public function update(Request $request, $id)
    {
        // Récupérer le terminal à mettre à jour par son identifiant ($id)
        $terminal = Terminal::find($id);
        // $user = auth()->user();
        $userId = $request->user_id ? $request->user_id : auth()->user()->id;
        $user = User::find($userId);


        // Si le terminal n'est pas trouvé, retourner une réponse d'erreur avec un code d'état 404
        if (!$terminal) {
            return response()->json([
                'success' => false,
                'message' => 'Le terminal spécifié est introuvable.',
            ], 404);
        }

        // Si l'utilisateur n'est pas associé à un centre, retourner une réponse d'erreur
        if (!$user->idcentre) {
            return response()->json([
                'success' => false,
                'message' => "L'utilisateur n'est pas associé à un centre.",
            ], 400);
        }

        // Valider les données du formulaire
        $validatedData = $request->validate([
            'nom' => 'required|string|max:255',
            'Description' => 'required|string|max:255',
            // Ajouter ici d'autres règles de validation pour les autres champs du modèle Terminal si nécessaire
        ]);

        // Mettre à jour les propriétés du modèle Terminal avec les données validées
        $terminal->is_synced = 0;
        $terminal->nom = $validatedData['nom'];
        // Ne pas mettre à jour le champ idcentre car cela ne devrait pas changer lors de la mise à jour
        $terminal->Description = $validatedData['Description'];
        $terminal->deleted_at = $request->input('deleted_at', 0);



        // Mettez à jour ici d'autres propriétés du modèle Terminal avec les données validées si nécessaire

        // Enregistrer les modifications dans la base de données
        $terminal->save();

        return response()->json([
            'success' => true,
            'data' => $terminal,
            'message' => 'Le terminal a été mis à jour avec succès.'
        ]);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $terminal = Terminal::find($id);

        // Supprimer le pays de la base de données
        $terminal->update(['is_synced' => 0]);
        $terminal->update(['deleted_at' => 1]);

        return response()->json([
            'success' => true,
            'message' => 'Terminal supprimé avec succès.'
        ]);
    }

    public function synchroniserTerminals()
    {

        // Récupérer l'utilisateur authentifié

        $accessToken = config('app.API_ACCESS_TOKEN');

        $url = 'http://www.google.com';

        $timeout = 5;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Vérifier le statut de la connexion Internet

        if ($httpCode == 200) {



            // $patientsNonSync = patient::where('is_synced', 0)->get();
            $terminalsNonSync = Terminal::where('is_synced', 0)->get();


            $headers = [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $accessToken,
            ];


            foreach ($terminalsNonSync as $terminal) {


                // $response = Http::get('https://api-medpay.akasigroup.net/api/patient/' . $patient->id);

                $response =  Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/terminals/' . $terminal->id);

                if ($response->successful()) {

                    Log::info('enregistrement trouvé ');
                    // Log::info($response->json());


                    // Si le patient existe en ligne, mettre à jour les informations

                    $response =  Http::withHeaders($headers)->put('https://api-medpay.akasigroup.net/api/terminals/' . $terminal->id, $terminal->toArray());

                    Log::info('Modification effectué ');
                } else {

                    // Sinon, si le patient est nouveau (n'a jamais été synchronisé), l'envoyer en ligne

                    $data = $terminal->toArray();

                    $response = Http::withHeaders($headers)->post('https://api-medpay.akasigroup.net/api/terminals', $data);
                    Log::info('Enregistrement effectué : ' . json_encode($response->json())  );

                }

                if ($response->successful()) {
                    // Mettre à jour le statut de synchronisation du patient en local
                    $terminal->is_synced = 1;
                    $terminal->save();
                    Log::info('terminal synchronisé avec succès. id : ' . $terminal->id);
                } else {

                    Log::error('Erreur lors de la synchronisation du termianl. id : ' . $terminal->id);
                }
            }


            $terminalsNonSyncdeleted = Terminal::where('is_synced', 0)->where('deleted_at', 1)->get();

            if ($terminalsNonSyncdeleted) {

                foreach ($terminalsNonSyncdeleted as  $terminalidSupprime) {
                    // Vérifier si l'ID existe en ligne avant de le supprimer

                    $response = Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/terminals/' . $terminalidSupprime->id);



                    if ($response->successful()) {
                        // Supprimer le patient en ligne
                        $deleteResponse = Http::withHeaders($headers)->delete('https://api-medpay.akasigroup.net/api/terminals/' . $terminalidSupprime->id);
                        Log::info('Terminal récupéré  effectué ');

                        if ($deleteResponse->successful()) {
                            $terminalidSupprime->is_synced = 1;
                            $terminalidSupprime->save();
                            Log::info('Terminal supprimé en ligne avec succès. ID : ' . $terminalidSupprime->id);
                            // Supprimer l'ID de la liste après la suppression réussie

                        } else {
                            Log::error('Erreur lors de la suppression en ligne du terminal. ID : ' . $terminalidSupprime->id);
                        }
                    } else {
                        Log::warning('Patient non trouvé en ligne. ID : ' . $terminalidSupprime);
                    }
                }
            }
        } else {
            Log::error('Internet connection is not available.');
        }
    }
}
