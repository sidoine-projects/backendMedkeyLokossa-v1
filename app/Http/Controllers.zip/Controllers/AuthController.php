<?php

namespace App\Http\Controllers;


use App\Models\User;
use Illuminate\Http\Request;
use App\Mail\PasswordResetMail;
use Illuminate\Http\JsonResponse;
use Spatie\Permission\Models\Role;

use Illuminate\Support\Facades\Log;


use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Password;
use Spatie\Permission\Models\Permission;


class AuthController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required',

        ]);

        if (Auth::attempt($credentials)) {
            $user = Auth::user();
            $token = $user->createToken('authToken')->plainTextToken;
            Log::info(openssl_get_cert_locations());


            return response()->json([
                'token' => $token,
                'user' => $user,
                'permissions' => $user->getAllPermissions()->pluck('name'),
                'message' => 'OK',
            ]);
        } else {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }
    }
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'message' => 'Logged out successfully',
        ]);
    }

    //     public function logout()
    // {
    //     $user = Auth::user();
    //     $user->tokens()->delete();

    //     return response()->json(['message' => 'Logout successful']);
    // }


    public function updatePassword(Request $request)
    {
        $request->validate([
            'password' => 'required',
            'new_password' => 'required|min:6',
        ]);
        $user = User::where('email', $request->email)->first();
        if ($user == null) {
            return response()->json([

                'message' => 'Utilisateur non trouvé',
            ]);
        }
        if (Hash::check($request->password, $user->password)) {
            $user->update([
                'password' => Hash::make($request->new_password),
            ]);

            return response()->json([
                'message' => 'Password updated successfully',
            ]);
        } else {
            return response()->json([
                'message' => 'Invalid password',
            ], 401);
        }
    }

    public function reset(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email',
                'password' => ['required', 'min:8', 'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/'],
                'password_confirmation' => 'required|min:8|same:password',
            ]);

            if ($request->password !== $request->password_confirmation) {
                return response()->json([
                    'message' => 'Les mots de passe ne sont pas conformes',
                ], 400);
            }

            $user = User::where('email', $request->email)->first();
            if ($user != null) {
                $user->password = Hash::make($request->password);
                $user->save();
                return response()->json([
                    'message' => 'Mot de passe réinitialisé avec succès',
                ], 200);
            } else {
                return response()->json([
                    'message' => 'Utilisateur non trouvé',
                ], 400);
            }
        } catch (\Exception $e) {
            // Attrapez l'exception et renvoyez une réponse d'erreur appropriée
            return response()->json([
                'message' => 'Une erreur s\'est produite lors de la réinitialisation du mot de passe',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        $token = $user->createToken('authToken')->plainTextToken;

        return response()->json([
            'token' => $token,
            'message' => 'User registered successfully',
        ]);
    }
    public function requestPassword(Request $request)
    {
        $user = User::where('email', $request->email)->first();

        if ($user == null) {
            return response()->json([
                'message' => 'Utilisateur non trouvé',
            ]);
        }


        // Vérifier si l'e-mail est valide
        if (!filter_var($request->email, FILTER_VALIDATE_EMAIL)) {
            return response()->json([
                'message' => 'Veuillez entrer un e-mail valide',
            ]);
        }

        // Générer le token de réinitialisation de mot de passe
        $token = Password::createToken($user);

        // Générer le lien de réinitialisation de mot de passe
        // $resetLink = 'http://localhost:8080/medpay/v1/auth-pages/reset/' . $token;
        $resetLink = 'http://localhost:8080/auth-pages/reset?token=' . $token;


        // Envoyer l'e-mail de réinitialisation de mot de passe
        Mail::to($user->email)->send(new PasswordResetMail($user, $resetLink));

        return response()->json([
            'message' => 'Email envoyé avec succès',
        ]);
    }



    public function showLoginForm()
    {
        return view('auth.login');
    }
}
