<?php

namespace App\Http\Controllers;

use App\Models\Assurance;
use App\Models\Compagnie;
use Illuminate\Http\Request;

class CompagnieController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $compagnies = Compagnie::orderBy('created_at', 'desc')->get();

        return response()->json([
            'success' => true,
            'data' => $compagnies,
            'message' => 'Liste des compagnies d\'assurance récupérée avec succès.'
        ]);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nom' => 'required|string',
            'telephone' => 'required|string|unique:compagnies_d_assurance',
            'email' => 'required|string|email|unique:compagnies_d_assurance',
            'adresse' => 'required|string',
        ]);

        $compagnie = new Compagnie();
        $compagnie->nom = $request->nom;
        $compagnie->telephone = $request->telephone;
        $compagnie->email = $request->email;
        $compagnie->adresse = $request->adresse;
        $compagnie->save();

        return response()->json([
            'success' => true,
            'data' => $compagnie,
            'message' => 'Compagnie d\'assurance ajoutée avec succès.'
        ]);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $compagnie = Compagnie::find($id);

        if (!$compagnie) {
            return response()->json([
                'success' => false,
                'message' => 'Compagnie d\'assurance non trouvée.'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $compagnie,
            'message' => 'Détails de la compagnie d\'assurance récupérés avec succès.'
        ]);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'nom' => 'required',
            'telephone' => 'required',
            'email' => 'required|email',
            'adresse' => 'required',
        ]);

        $compagnie = Compagnie::find($id);

        if (!$compagnie) {
            return response()->json([
                'success' => false,
                'message' => 'Compagnie d\'assurance non trouvée.'
            ], 404);
        }

        $compagnie->nom = $request->nom;
        $compagnie->telephone = $request->telephone;
        $compagnie->email = $request->email;
        $compagnie->adresse = $request->adresse;
        $compagnie->save();

        return response()->json([
            'success' => true,
            'data' => $compagnie,
            'message' => 'Compagnie d\'assurance mise à jour avec succès.'
        ]);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $compagnie = Compagnie::find($id);

        if (!$compagnie) {
            return response()->json([
                'success' => false,
                'message' => 'Compagnie d\'assurance non trouvée.'
            ], 404);
        }

        $compagnie->delete();

        return response()->json([
            'success' => true,
            'message' => 'Compagnie d\'assurance supprimée avec succès.'
        ]);
    }

    public function getAssuranceByCompagnie($compagnieId)
    {
        try {
            // Recherche de la compagnie par son ID
            $compagnie = Compagnie::findOrFail($compagnieId);

            // Récupération des assurances associées à la compagnie
            $assurances = Assurance::where('compagnie_d_assurance_id', $compagnie->id)->get();

            return response()->json([
                'success' => true,
                'data' => $assurances,
                'message' => 'Assurances associées à la compagnie récupérées avec succès.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Une erreur est survenue lors de la récupération des assurances associées à la compagnie.',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}