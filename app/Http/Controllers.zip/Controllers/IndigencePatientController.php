<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use App\Models\Indigence;
use Illuminate\Http\Request;
use App\Models\IndigencePatient;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;

class IndigencePatientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $user = auth()->user();
        $centreId = $user->idcentre;

        $roleId = $user->role_id;


        $indigences = IndigencePatient::with('patient:id,nom,prenom,age')
            ->join('users', 'indigencepatient.user_id', '=', 'users.id')
            ->join('centresanitaires', 'users.idcentre', '=', 'centresanitaires.id')
            ->where('users.idcentre', $centreId)
            ->where('indigencepatient.deleted_at', 0)
            ->orderBy('indigencepatient.created_at', 'desc')
            ->get();

        if ($roleId == 10 || $roleId == 1) {

            $indigences = IndigencePatient::with('patient:id,nom,prenom,age')
                ->where('deleted_at', 0)
                ->get();
        }


        return response()->json([
            'success' => true,
            'data' => $indigences,
            'message' => 'Liste des indigences récupérée avec succès.'
        ]);
    }




    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // public function store(Request $request)
    // {
    //     // Validation des données entrantes
    //     $validatedData = $request->validate([

    //         'indigence_id' => 'required|integer',
    //         'pourcentage' => 'required|numeric',
    //         'patient_id' => 'required|integer'
    //     ]);

    //     // Création d'une nouvelle instance d'IndigencePatient
    //     $indigence = new IndigencePatient();
    //     // $indigence->age = $validatedData['age'];


    //     $age = 20;

    //     $indigenceid =  Indigence::where('agemin', '<=', $age)
    //         ->where('agemax', '>=', $age)
    //         ->first();


    //     $indigence->indigence_id = $indigenceid->id;
    //     $indigence->pourcentage = $validatedData['pourcentage'];
    //     $indigence->patient_id = $validatedData['patient_id'];

    //     // Enregistrement de l'indigence dans la base de données
    //     $indigence->save();

    //     // Réponse JSON avec les données de l'indigence nouvellement créée
    //     return response()->json([
    //         'success' => true,
    //         'data' => $indigence,
    //         'message' => 'Indigence enregistrée avec succès.'
    //     ], 201);
    // }

    public function store(Request $request)
    {
        // Validation des données entrantes
        $validatedData = $request->validate([
            'pourcentage' => 'required|numeric',
            'patient_id' => 'required|integer',
            'datedebut' => 'required|date',
            'datefin' => 'required|date',
        ]);


        // Récupérer l'âge du patient à partir de son ID
        $patient = Patient::find($validatedData['patient_id']);
        if (!$patient) {
            return response()->json([
                'success' => false,
                'message' => 'Patient introuvable.'
            ], 404);
        }

        $age = $patient->age;

        // Récupérer l'indigence correspondant à l'âge du patient
        $indigence = Indigence::where('agemin', '<=', $age)
            ->where('agemax', '>=', $age)
            ->first();

        if (!$indigence) {
            return response()->json([
                'success' => false,
                'message' => 'Indigence introuvable pour l\'âge du patient.'
            ], 404);
        }

        // Vérifier si une indigence similaire existe déjà pour le patient et l'indigence_id
        $existingIndigence = IndigencePatient::where('patient_id', $validatedData['patient_id'])
            ->where('indigence_id', $indigence->id)
            ->first();

        if ($existingIndigence) {
            return response()->json([
                'success' => false,
                'message' => 'Une indigence similaire existe déjà pour ce patient.'
            ], 400);
        }
        // Récupérer l'ID de l'utilisateur connecté
        // $userId = auth()->user()->id;
        $userId = $request->user_id ? $request->user_id : auth()->user()->id;

        // Création d'une nouvelle instance d'IndigencePatient

        $indigencePatient = new IndigencePatient();
        $indigencePatient->is_synced = 0;
        $indigencePatient->user_id = $userId;
        $indigencePatient->indigence_id = $indigence->id;
        $indigencePatient->is_synced = 0;

        $indigencePatient->pourcentage = $validatedData['pourcentage'];
        $indigencePatient->patient_id = $validatedData['patient_id'];
        $indigencePatient->datedebut = $validatedData['datedebut'];
        $indigencePatient->datefin = $validatedData['datefin'];
        // $indigencePatient->deleted_at = $validatedData['deleted_at'] ?? 0;
        $indigencePatient->deleted_at = $request->input('deleted_at', 0);

        // Enregistrement de l'indigence patient dans la base de données
        $indigencePatient->save();

        // Réponse JSON avec les données de l'indigence nouvellement créée
        return response()->json([
            'success' => true,
            'data' => $indigencePatient,
            'message' => 'Indigence enregistrée avec succès.'
        ], 201);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // Recherche de l'indigence par ID
        $indigence = IndigencePatient::find($id);

        // Vérification si l'indigence existe
        if (!$indigence) {
            return response()->json([
                'success' => false,
                'message' => 'Indigence introuvable.'
            ], 404);
        }

        // Réponse JSON avec les données de l'indigence
        return response()->json([
            'success' => true,
            'data' => $indigence
        ]);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,  $id)
    {
        // Validation des données entrantes

        $validatedData = $request->validate([
            'pourcentage' => 'required|numeric',
            'patient_id' => 'required|integer',
            'datedebut' => 'required|date',
            'datefin' => 'required|date',
        ]);

        // Récupérer l'âge du patient à partir de son ID
        $patient = Patient::find($validatedData['patient_id']);
        if (!$patient) {
            return response()->json([
                'success' => false,
                'message' => 'Patient introuvable.'
            ], 404);
        }

        $age = $patient->age;

        // Récupérer l'indigence correspondant à l'âge du patient
        $indigence = Indigence::where('agemin', '<=', $age)
            ->where('agemax', '>=', $age)
            ->first();

        if (!$indigence) {
            return response()->json([
                'success' => false,
                'message' => 'Indigence introuvable pour l\'âge du patient.'
            ], 404);
        }

        // Rechercher l'indigence patient à mettre à jour
        $indigencePatient = IndigencePatient::find($id);
        // if (!$indigencePatient) {
        //     return response()->json([
        //         'success' => false,
        //         'message' => 'Indigence patient introuvable.'
        //     ], 404);
        // }

        // Mettre à jour les attributs de l'indigence patient
        $indigencePatient->is_synced = 0;
        $indigencePatient->indigence_id =   $indigence->id;
        $indigencePatient->pourcentage = $validatedData['pourcentage'];
        $indigencePatient->patient_id = $validatedData['patient_id'];
        $indigencePatient->datedebut = $validatedData['datedebut'];
        $indigencePatient->datefin = $validatedData['datefin'];
        $indigencePatient->deleted_at = $request->input('deleted_at', 0);

        // Enregistrement de l'indigence patient mis à jour dans la base de données
        $indigencePatient->save();

        // Réponse JSON avec les données de l'indigence patient mis à jour
        return response()->json([
            'success' => true,
            'data' => $indigencePatient,
            'message' => 'Indigence patient mise à jour avec succès.'
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Recherche de l'indigence par ID
        $indigence = IndigencePatient::find($id);

        // Vérification si l'indigence existe
        if (!$indigence) {
            return response()->json([
                'success' => false,
                'message' => 'Indigence introuvable.'
            ], 404);
        }

        // Suppression de l'indigence
        // $indigence->delete();
        $indigence->update(['is_synced' => 0]);
        $indigence->update(['deleted_at' => 1]);

        // Réponse JSON avec un message de succès
        return response()->json([
            'success' => true,
            'message' => 'Indigence supprimée avec succès.'
        ]);
    }




    public function getPercentageByAge($patientId)
    {
        // $age = Patient::find($patientId)->age; // Supposons que vous ayez une colonne 'age' dans votre modèle Patient

        $pourcentage = IndigencePatient::where('patient_id', '=', $patientId)
            ->value('pourcentage');


        return response()->json([
            'success' => true,
            'data' => $pourcentage,
            'message' => 'Pourcentage trouvé.'
        ]);
    }

    public function getPercentageBy($patientId)
    {
        $age = Patient::find($patientId)->age; // Supposons que vous ayez une colonne 'age' dans votre modèle Patient

        $pourcentage = Indigence::where('agemin', '<=', $age)
            ->where('agemax', '>=', $age)
            ->value('pourcentage');


        if (!$pourcentage) {
            $pourcentage = 0; // Définit le pourcentage à 0 si aucun pourcentage n'est trouvé
        }


        return response()->json([
            'success' => true,
            'data' => $pourcentage,
            'message' => 'Pourcentage trouvé.'
        ]);
    }

    public function synchroniserIndigencePatients()
    {

        // Récupérer l'utilisateur authentifié

        $accessToken = config('app.API_ACCESS_TOKEN');

        $url = 'http://www.google.com';

        $timeout = 5;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Vérifier le statut de la connexion Internet

        if ($httpCode == 200) {



            // $patientsNonSync = patient::where('is_synced', 0)->get();
            $indigencepatientsNonSync = IndigencePatient::where('is_synced', 0)->get();


            $headers = [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $accessToken,
            ];


            foreach ($indigencepatientsNonSync as $indigencepatients) {


                // $response = Http::get('https://api-medpay.akasigroup.net/api/patient/' . $patient->id);

                $response =  Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/indigencespatients/' . $indigencepatients->id);

                if ($response->successful()) {

                    Log::info('enregistrement trouvé ');
                    // Log::info($response->json());


                    // Si le patient existe en ligne, mettre à jour les informations

                    $response =  Http::withHeaders($headers)->put('https://api-medpay.akasigroup.net/api/indigencespatients/' . $indigencepatients->id, $indigencepatients->toArray());

                    Log::info('Modification effectué ');
                } else {

                    // Sinon, si le patient est nouveau (n'a jamais été synchronisé), l'envoyer en ligne

                    $data = $indigencepatients->toArray();

                    $response = Http::withHeaders($headers)->post('https://api-medpay.akasigroup.net/api/indigencespatients', $data);
                }

                if ($response->successful()) {
                    // Mettre à jour le statut de synchronisation du patient en local
                    $indigencepatients->is_synced = 1;
                    $indigencepatients->save();
                    Log::info('Indigence patient synchronisé avec succès. id : ' . $indigencepatients->id);
                } else {

                    Log::error('Erreur lors de la synchronisation de l\'patient. id : ' . $indigencepatients->id);
                }
            }


            $indigencepatientsNonSyncdeleted = IndigencePatient::where('is_synced', 0)->where('deleted_at', 1)->get();

            if ($indigencepatientsNonSyncdeleted) {

                foreach ($indigencepatientsNonSyncdeleted as   $indigencepatientidSupprime) {
                    // Vérifier si l'ID existe en ligne avant de le supprimer

                    $response = Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/indigencespatients/' .  $indigencepatientidSupprime->id);



                    if ($response->successful()) {
                        // Supprimer le patient en ligne
                        $deleteResponse = Http::withHeaders($headers)->delete('https://api-medpay.akasigroup.net/api/indigencespatients/' . $indigencepatientidSupprime->id);
                        Log::info('Patient récupéré  effectué ');

                        if ($deleteResponse->Successful()) {
                            $indigencepatientidSupprime->is_synced = 1;
                            $indigencepatientidSupprime->save();
                            Log::info('Indigence Patient supprimé en ligne avec succès. ID : ' . $indigencepatientidSupprime->id);
                            // Supprimer l'ID de la liste après la suppression réussie

                        } else {
                            Log::error('Erreur lors de la suppression en ligne de indigence patient. ID : ' . $indigencepatientidSupprime->id);
                        }
                    } else {
                        Log::warning('Indigence Patient non trouvé en ligne. ID : ' . $indigencepatientidSupprime);
                    }
                }
            }
        } else {
            Log::error('Internet connection is not available.');
        }
    }




    // public function getPercentageByAge($patientId)
    // {
    //     $pourcentage = IndigencePatient::find($patientId)->pourcentage; // Supposons que vous ayez une colonne 'age' dans votre modèle Patient


    //         return response()->json([
    //             'success' => true,
    //             'data' => $pourcentage,
    //             'message' => 'Pourcentage trouvé.'
    //         ]);

    // }







}
