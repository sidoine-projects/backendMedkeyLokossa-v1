<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Models\CentreSanitaire;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;

// use Illuminate\Foundation\Auth\User;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    // public function index()
    // {
    //     //
    // }444
    public function index()
    {
        $user = auth()->user();

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Utilisateur non authentifié.'
            ], 401);
        }

        if ($user->role_id === 10) { // Vérifie si l'utilisateur a le rôle super_admin
            // $allUsers = User::all(); // Récupère tous les utilisateurs

            $allUsers = User::with('role')->where('deleted_at', '0')->orderBy('created_at', 'desc')->get();
            return response()->json([
                'success' => true,
                'data' => $allUsers,
            ]);
        } elseif ($user->hasRole('Directeur')) {

            $centreId = $user->idcentre;

            // Récupère les utilisateurs du même centre que le Directeur
            $usersInSameCentre = User::where('idcentre', $centreId)
                ->where('role_id', '<>', 10) // Exclut le rôle "super_admin" s'il existe
                ->with('role')
                ->where('deleted_at', '0')
                ->orderBy('created_at', 'desc')
                ->get();

            return response()->json([
                'success' => true,
                'data' => $usersInSameCentre,
            ]);
        } else {

            $centreId = $user->idcentre;

            $getCaissiers = User::where('idcentre', $centreId)
                ->where('role_id', 4) // Filtre les utilisateurs caissier ayant le rôle avec ID 4 (caissier)
                ->where('deleted_at', '0')
                ->orderBy('created_at', 'desc')
                ->get();

            return response()->json([
                'success' => true,
                'data' => $getCaissiers,
            ]);
        }
    }


    // public function index()
    // {
    //     $user = auth()->user();

    //     if (!$user) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Utilisateur non authentifié.'
    //         ], 401);
    //     }

    //     if ($user->role_id === 10) { // Vérifie si l'utilisateur a le rôle super_admin
    //         $allUsers = User::with('role')->get();
    //         return response()->json([
    //             'success' => true,
    //             'data' => $allUsers,
    //         ]);
    //     } elseif ($user->hasRole('Directeur')) {
    //         $centreId = $user->idcentre;

    //         // Compter le nombre d'utilisateurs du même centre que le Directeur
    //         $userCountSameCentre = User::where('idcentre', $centreId)
    //             ->where('role_id', '<>', 10) // Exclut le rôle "super_admin" s'il existe
    //             ->count();

    //         if ($userCountSameCentre >= 10) {
    //             return response()->json([
    //                 'success' => false,
    //                 'message' => 'La limite d\'utilisateurs connectés pour ce centre est atteinte. Vous ne pouvez pas afficher plus d\'utilisateurs.',
    //             ], 400);
    //         }

    //         // Récupère les utilisateurs du même centre que le Directeur
    //         $usersInSameCentre = User::where('idcentre', $centreId)
    //             ->where('role_id', '<>', 10) // Exclut le rôle "super_admin" s'il existe
    //             ->with('role')
    //             ->get();

    //         return response()->json([
    //             'success' => true,
    //             'data' => $usersInSameCentre,
    //         ]);
    //     } else {
    //         if (!property_exists($user, 'idcentre')) {
    //             return response()->json([
    //                 'success' => false,
    //                 'message' => "L'utilisateur n'a pas la propriété idcentre."
    //             ], 400);
    //         }

    //         $centreId = $user->idcentre;

    //         $getCaissiers = User::where('idcentre', $centreId)
    //             ->where('role_id', 4) // Filtre les utilisateurs caissier ayant le rôle avec ID 4 (caissier)
    //             ->get();

    //         return response()->json([
    //             'success' => true,
    //             'data' => $getCaissiers,
    //         ]);
    //     }
    // }




    // public function store(Request $request)
    // {

    //     // Vérifier si le nombre d'utilisateurs dépasse 3
    //     $userCount = User::count();
    //     if ($userCount >= 10) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'La limite d\'utilisateurs est atteinte. Vous ne pouvez pas ajouter plus d\'utilisateurs.',
    //         ], 400);
    //     }

    //     // Validation des données entrantes
    //     $validatedData = $request->validate([
    //         'name' => 'required|string',
    //         'prenom' => 'required|string',
    //         'email' => 'required|email|unique:users',
    //         'nom_utilisateur' => 'required|string|unique:users',
    //         'adresse' => 'required|string',
    //         'role_id' => 'required|integer',
    //         'telephone' => 'required|string|min:8 |unique:users',
    //         'sexe' => 'required|string',
    //         'password' => 'required|string',
    //         'idcentre' => 'required|integer',
    //     ]);

    //     $role = Role::find($validatedData['role_id']);

    //     if (!$role) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Le rôle spécifié n\'existe pas.',
    //         ], 404);
    //     }

    //     // Création d'un nouvel utilisateur
    //     $user = User::create([
    //         'is_synced' => 0,
    //         'name' => $validatedData['name'],
    //         'prenom' => $validatedData['prenom'],
    //         'email' => $validatedData['email'],
    //         'nom_utilisateur' => $validatedData['nom_utilisateur'],
    //         'adresse' => $validatedData['adresse'],
    //         'role_id' => $validatedData['role_id'],
    //         'telephone' => $validatedData['telephone'],
    //         'sexe' => $validatedData['sexe'],
    //         'password' => bcrypt($validatedData['password']),
    //         // 'idcentre' => $validatedData['idcentre'],
    //         'idcentre' => $role->name === 'Admin' ? null : $validatedData['idcentre'],
    //         // Set idcentre to null for admin role, otherwise use the provided value
    //         'deleted_at' => $request->input('deleted_at', 0),
    //     ]);

    //     $user->assignRole($role);

    //     // Réponse JSON avec les données du nouvel utilisateur
    //     return response()->json([
    //         'success' => true,
    //         'data' => $user,
    //         'message' => 'Utilisateur créé avec succès.'
    //     ], 201);
    // }

    public function store(Request $request)
    {

        // Vérifier si le nombre d'utilisateurs dépasse 3

        $userCount = User::where('deleted_at', '0')->count();

        // if ($userCount >= 5) {
        //     return response()->json([
        //         'success' => false,
        //         'message' => 'La limite d\'utilisateurs est atteinte. Vous ne pouvez pas ajouter plus d\'utilisateurs.',
        //     ], 400);
        // }

        // Validation des données entrantes
        $validatedData = $request->validate([
            'name' => 'required|string',
            'prenom' => 'required|string',
            'email' => [
                'required',
                'email',
                Rule::unique('users')->where(function ($query) {
                    $query->where('deleted_at', 0);
                }),
            ],
            'nom_utilisateur' => [
                'required',
                'string',
                Rule::unique('users')->where(function ($query) {
                    $query->where('deleted_at', 0);
                }),
            ],
            'adresse' => 'required|string',
            'role_id' => 'required|integer',
            // 'telephone' => 'required|string|min:8|unique:users',
            'telephone' => [
                'required',
                'numeric',
                'digits:8',
                Rule::unique('users')->where(function ($query) {
                    $query->where('deleted_at', 0);
                }),
            ],
            'sexe' => 'required|string',
            'password' => 'required|string',
            'idcentre' => 'required|integer',
        ]);


        // Recherche de l'utilisateur connecté
        $loggedInUser = Auth::user();

        $centreId = $loggedInUser->idcentre;
        $usersInSameCentre = User::where('idcentre', $centreId)->where('deleted_at', '0')
            ->with('role')
            ->get();

        // Vérifier si l'utilisateur connecté a le rôle "Super_admin" ou "Directeur"
        $superAdminRole = Role::where('name', 'Super_admin')->first();
        $directeurRole = Role::where('name', 'Directeur')->first();
        // || $loggedInUser->hasRole($directeurRole)

        if ($loggedInUser->hasRole($superAdminRole)) {
            // Compter le nombre d'utilisateurs connectés du même centre
            $userCountSameCentre = User::where('idcentre', $validatedData['idcentre'])->where('deleted_at', '0')->count();

            if ($userCountSameCentre >= 5) {
                return response()->json([
                    'success' => false,
                    'data' => [
                        'user' => $usersInSameCentre,
                        'userCountSameCentre' => $userCountSameCentre
                    ],
                    'message' => 'La limite d\'utilisateurs connectés pour ce centre est atteinte. Vous ne pouvez pas ajouter plus d\'utilisateurs connectés.',
                ]);
            }
        }


        if ($loggedInUser->hasRole($directeurRole)) {
            // Compter le nombre d'utilisateurs connectés du même centre
            $userCountSameCentre = User::where('idcentre', $validatedData['idcentre'])->where('deleted_at', '0')->count();

            if ($userCountSameCentre >= 5) {
                return response()->json([
                    'success' => false,
                    'data' => [
                        'user' => $usersInSameCentre,
                        'userCountSameCentre' => $userCountSameCentre
                    ],
                    'message' => 'La limite d\'utilisateurs connectés pour ce centre est atteinte. Vous ne pouvez pas ajouter plus d\'utilisateurs connectés.',
                ]);
            }
        }



        $role = Role::find($validatedData['role_id']);

        if (!$role) {
            return response()->json([
                'success' => false,
                'message' => 'Le rôle spécifié n\'existe pas.',
            ], 404);
        }

        // Création d'un nouvel utilisateur
        $user = User::create([
            'is_synced' => 0,
            'name' => $validatedData['name'],
            'prenom' => $validatedData['prenom'],
            'email' => $validatedData['email'],
            'nom_utilisateur' => $validatedData['nom_utilisateur'],
            'adresse' => $validatedData['adresse'],
            'role_id' => $validatedData['role_id'],
            'telephone' => $validatedData['telephone'],
            'sexe' => $validatedData['sexe'],
            'password' => bcrypt($validatedData['password']),
            'idcentre' => $role->name === 'Admin' ? null : $validatedData['idcentre'],
            'deleted_at' => $request->input('deleted_at', 0),
        ]);

        $user->assignRole($role);

        // Réponse JSON avec les données du nouvel utilisateur
        return response()->json([
            'success' => true,
            // 'data' => $user, $userCountSameCentre,
            'data' => $user,
            'message' => 'Utilisateur créé avec succès.'
        ], 201);
    }



    /**
     * Display the specified resource.
     */
    // public function show(string $id)
    // {
    //     //
    // }
    public function show(string $id)
    {
        // Recherche de l'utilisateur par ID
        $user = User::find($id);

        // Vérification si l'utilisateur existe
        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Utilisateur introuvable.'
            ], 404);
        }

        // Réponse JSON avec les données de l'utilisateur
        return response()->json([
            'success' => true,
            'data' => $user
        ]);
    }



    //    fffffffff
    public function update(Request $request, string $id)
    {
        // Vérifier si l'utilisateur est authentifié
        if (!Auth::check()) {
            return response()->json([
                'success' => false,
                'message' => 'Vous devez être connecté pour effectuer cette action.'
            ], 401); // Code de statut HTTP 401 pour non autorisé
        }

        // Recherche de l'utilisateur connecté
        $loggedInUser = Auth::user();

        // Vérifier si l'utilisateur connecté a le rôle "Super_admin"
        $superAdminRole = Role::where('name', 'Super_admin')->first();

        // Vérifier si l'utilisateur connecté a le rôle "Admin"
        $adminRole = Role::where('name', 'Directeur')->first();

        if (!$superAdminRole || !$adminRole) {
            // Les rôles "Super_admin" et "Admin" doivent exister pour effectuer cette action.
            return response()->json([
                'success' => false,
                'message' => 'Rôles non trouvés. Veuillez vérifier la base de données.'
            ], 500); // Code de statut HTTP 500 pour erreur interne du serveur
        }

        // Vérifier si l'utilisateur connecté est un "Super_admin" ou un "Admin" et tente de modifier lui-même ou un autre "Admin"
        if (($loggedInUser->role_id === $superAdminRole->id || ($loggedInUser->role_id === $adminRole->id && $loggedInUser->id === $id)) ||
            ($loggedInUser->role_id === $adminRole->id && $loggedInUser->id !== $id)
        ) {
            // L'utilisateur connecté est soit un "Super_admin", soit un "Admin" qui tente de modifier lui-même ou un autre "Admin".
            // Autoriser la modification.

            // Validation des données entrantes
            $validatedData = $request->validate([
                'name' => 'required|string',
                'prenom' => 'required|string',
                'email' => [
                    'required',
                    'email',
                    'string',
                    Rule::unique('users')->where(function ($query) {
                        $query->where('deleted_at', 0);
                    })->ignore($id, 'id'),
                ],

                'nom_utilisateur' => [
                    'required',
                    'string',
                    Rule::unique('users', 'nom_utilisateur')->where(function ($query) {
                        $query->where('deleted_at', 0);
                    })->ignore($id, 'id'),
                ],
                'adresse' => 'required|string',
                'role_id' => 'required|integer',
                // 'telephone' => 'required|string|unique:users',
                'telephone' => [
                    'required',
                    'digits:8',
                    'numeric',
                    Rule::unique('users')->where(function ($query) {
                        $query->where('deleted_at', 0);
                    })->ignore($id, "id"),
                ],

                'sexe' => 'required|string',
                'idcentre' => 'required|integer',
            ]);

            // Recherche de l'utilisateur par ID
            $user = User::find($id);

            // Vérification si l'utilisateur existe
            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'Utilisateur introuvable.'
                ], 404);
            }

            // Mise à jour des données de l'utilisateur
            $user->is_synced = 0;
            $user->name = $validatedData['name'];
            $user->prenom = $validatedData['prenom'];
            $user->email = $validatedData['email'];
            $user->nom_utilisateur = $validatedData['nom_utilisateur'];
            $user->adresse = $validatedData['adresse'];
            $user->role_id = $validatedData['role_id'];
            $user->telephone = $validatedData['telephone'];
            $user->sexe = $validatedData['sexe'];
            $user->idcentre = $validatedData['idcentre'];
            $user->deleted_at = $request->input('deleted_at', 0);
            $user->save();

            // Synchronisation des rôles
            $newRole = Role::find($validatedData['role_id']);
            $user->syncRoles([$newRole]);

            // Synchronisation des permissions associées au rôle
            $permissions = $newRole->permissions;
            $user->syncPermissions($permissions);

            // Réponse JSON avec les données mises à jour de l'utilisateur
            return response()->json([
                'success' => true,
                'data' => $user,
                'message' => 'Utilisateur mis à jour avec succès.'
            ]);
        } else {
            // L'utilisateur connecté n'est pas autorisé à effectuer cette action.
            return response()->json([
                'success' => false,
                'message' => 'Vous n\'êtes pas autorisé à effectuer cette action.'
            ], 403); // Code de statut HTTP 403 pour interdit
        }
    }





    /**
     * Remove the specified resource from storage.
     */
    // public function destroy(string $id)
    // {
    //     //
    // }
    public function destroy(string $id)
    {
        // Recherche de l'utilisateur par ID
        $user = User::find($id);

        // Vérification si l'utilisateur existe
        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Utilisateur introuvable.'
            ], 404);
        }

        // Suppression de l'utilisateur
        // $user->delete();
        $user->update(['is_synced' => 0]);
        $user->update(['deleted_at' => 1]);

        // Réponse JSON avec un message de succès
        return response()->json([
            'success' => true,
            'message' => 'Utilisateur supprimé avec succès.'
        ]);
    }



    public function getCaissierByCenter()
    {
        $user = auth()->user();

        $centreId = $user->idcentre;

        $getCaissiers = User::where('idcentre', $centreId)->where('role_id', 4) // Filtre les utilisateurs caissier ayant le rôle avec ID 4 (caissier)
            ->get();



        return response()->json([
            'success' => true,
            'message' => 'liste des factures de ce jour et la list des caissiers de l\'hopital',
            'data' =>  [
                'caissiers' => $getCaissiers,
            ],

        ]);
    }

    public function getCurrentUserCentre()
    {
        $user = auth()->user();
        if ($user) {
            $centreSanitaire = $user->centreSanitaire;
            if ($centreSanitaire) {
                return response()->json(['centreSanitaire' => $centreSanitaire], 200);
            } else {
                return response()->json(['message' => 'L\'utilisateur n\'est pas associé à un centre sanitaire.'], 404);
            }
        } else {
            return response()->json(['message' => 'Utilisateur non connecté.'], 401);
        }
    }

    public function showProfile(Request $request)
    {
        // Vérifier si l'utilisateur est connecté
        if (!Auth::check()) {
            return response()->json([
                'success' => false,
                'message' => 'Vous devez être connecté pour accéder à votre profil.'
            ], 401); // Code de statut HTTP 401 pour non autorisé
        }

        // Récupération de l'utilisateur connecté
        // $user = Auth::user();
        $user = $request->user();

        // Réponse JSON avec les données du profil de l'utilisateur connecté
        return response()->json([
            'success' => true,
            'data' => $user
        ]);
    }

    public function updatePassProfil(Request $request)
    {
        // Vérifier si l'utilisateur est connecté
        if (!Auth::check()) {
            return response()->json([
                'success' => false,
                'message' => 'Vous devez être connecté pour mettre à jour votre mot de passe.'
            ], 401); // Code de statut HTTP 401 pour non autorisé
        }

        // Validation des données entrantes
        $validatedData = $request->validate([
            'old_password' => 'required|string',
            'new_password' => 'required|string|min:8|different:old_password|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/',
            'confirm_password' => 'required|string|same:new_password',
        ]);

        // Récupération de l'utilisateur connecté
        // $user = Auth::user();
        $user = $request->user();

        // Vérification du mot de passe actuel de l'utilisateur
        if (!Hash::check($validatedData['old_password'], $user->password)) {
            return response()->json([
                'success' => false,
                'message' => 'Le mot de passe actuel est incorrect.'
            ], 400);
        }

        // Mise à jour du mot de passe de l'utilisateur
        $user->password = bcrypt($validatedData['new_password']);
        $user->save();

        // Réponse JSON avec un message de succès
        return response()->json([
            'success' => true,
            'message' => 'Mot de passe mis à jour avec succès.'
        ]);
    }

    public function updateProfile(Request $request)
    {
        // Vérifier si l'utilisateur est connecté
        if (!Auth::check()) {
            return response()->json([
                'success' => false,
                'message' => 'Vous devez être connecté pour mettre à jour vos informations de base.'
            ], 401); // Code de statut HTTP 401 pour non autorisé
        }

        // Validation des données entrantes
        $validatedData = $request->validate([
            'name' => 'required|string',
            'prenom' => 'required|string',
            'email' => ['required', 'email', 'string', Rule::unique('users')->ignore(Auth::user()->id, "id")],
            'nom_utilisateur' => ['required', 'string', 'unique:users,nom_utilisateur,' . Auth::user()->id . ',id'],
            'adresse' => 'required|string',
            'telephone' => 'required|string|min:8',
            'sexe' => 'required|string',
            // 'idcentre' => 'required|integer',
        ]);

        // Récupération de l'utilisateur connecté
        $user = $request->user();
        // $user = Auth::user();

        // Mise à jour des informations de base de l'utilisateur
        $user->name = $validatedData['name'];
        $user->prenom = $validatedData['prenom'];
        $user->email = $validatedData['email'];
        $user->nom_utilisateur = $validatedData['nom_utilisateur'];
        $user->adresse = $validatedData['adresse'];
        $user->telephone = $validatedData['telephone'];
        $user->sexe = $validatedData['sexe'];
        // $user->idcentre = $validatedData['idcentre'];
        $user->save();

        // Réponse JSON avec les données mises à jour de l'utilisateur
        return response()->json([
            'success' => true,
            'data' => $user,
            'message' => 'Informations de base mises à jour avec succès.'
        ]);
    }





    public function updateUserOnline(Request $request, $id)
    {
        // Récupérer l'utilisateur existant en ligne par son ID

        $user = User::findOrFail($id);


        $user->name = $request->name;
        $user->email = $request->email;
        $user->prenom = $request->prenom;
        $user->nom_utilisateur = $request->nom_utilisateur;
        $user->adresse = $request->adresse;
        $user->telephone = $request->telephone;
        $user->sexe = $request->sexe;
        $user->role_id = $request->role_id;
        $user->idcentre = $request->idcentre;


        $user->deleted_at = 0;

        // Enregistrer les modifications dans la base de données
        $user->save();

        // Réponse JSON avec les données de l'utilisateur mis à jour
        return response()->json([
            'success' => true,
            'data' => $user,
            'message' => 'Utilisateur mis à jour avec succès.'
        ]);
    }







    public function storeUserOnline(Request $request)
    {

        // Création d'un nouvel utilisateur
        $user = User::create([
            'is_synced' => 0,
            'name' => $request->name,
            'email' => $request->email,
            'prenom' => $request->prenom,
            'nom_utilisateur' => $request->nom_utilisateur,
            'adresse' => $request->adresse,
            'telephone' => $request->telephone,
            'sexe' => $request->sexe,
            'password' =>   $request->password,
            'role_id' => $request->role_id,
            'idcentre' => $request->idcentre,
            'deleted_at' => $request->input('deleted_at', 0),
        ]);



        // Réponse JSON avec les données du nouvel utilisateur
        return response()->json([
            'success' => true,
            'data' => $user,
            'message' => 'Utilisateur créé avec succès.'
        ], 201);
    }


    public function synchroniserUsers()
    {

        // Récupérer l'utilisateur authentifié

        $accessToken = config('app.API_ACCESS_TOKEN');

        $url = 'http://www.google.com';

        $timeout = 5;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Vérifier le statut de la connexion Internet

        if ($httpCode == 200) {



            // $patientsNonSync = patient::where('is_synced', 0)->get();
            $usersNonSync = User::where('is_synced', 0)->get();


            $headers = [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $accessToken,
            ];


            foreach ($usersNonSync as $user) {

                $hashedPassword = $user->password;

                // $response = Http::get('https://api-medpay.akasigroup.net/api/patient/' . $patient->id);

                $response =  Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/users/' . $user->id);

                if ($response->successful()) {

                    Log::info('enregistrement trouvé ');


                    $data = [
                        'name' => $user->name,
                        'email' => $user->email,
                        'prenom' => $user->prenom,
                        'nom_utilisateur' => $user->nom_utilisateur,
                        'adresse' => $user->adresse,
                        'telephone' => $user->telephone,
                        'sexe' => $user->sexe,
                        'password' => $hashedPassword, // Ajouter le mot de passe haché
                        'role_id' => $user->role_id,
                        'idcentre' => $user->idcentre,
                        'deleted_at' => $user->deleted_at,
                    ];


                    // Si le patient existe en ligne, mettre à jour les informations

                    $response =  Http::withHeaders($headers)->put('https://api-medpay.akasigroup.net/api/updateuseronline/' . $user->id, $data);

                    Log::info('Modification effectué ');

                    Log::info('Data:' . json_encode($response->json()));
                } else {

                    // Sinon, si le patient est nouveau (n'a jamais été synchronisé), l'envoyer en ligne

                    $data = [
                        'name' => $user->name,
                        'email' => $user->email,
                        'prenom' => $user->prenom,
                        'nom_utilisateur' => $user->nom_utilisateur,
                        'adresse' => $user->adresse,
                        'telephone' => $user->telephone,
                        'sexe' => $user->sexe,
                        'password' => $hashedPassword, // Ajouter le mot de passe haché
                        'role_id' => $user->role_id,
                        'idcentre' => $user->idcentre,
                        'deleted_at' => $user->deleted_at,
                    ];

                    $response = Http::withHeaders($headers)->post('https://api-medpay.akasigroup.net/api/storeuseronline', $data);

                    Log::info('Data:' . json_encode($response->json()));
                }

                if ($response->successful()) {
                    // Mettre à jour le statut de synchronisation du patient en local
                    $user->is_synced = 1;
                    $user->save();
                    Log::info('User synchronisé avec succès. id : ' . $user->id);
                } else {

                    Log::error('Erreur lors de la synchronisation de user. id : ' . $user->id);
                }
            }


            $usersNonSyncdeleted = User::where('is_synced', 0)->where('deleted_at', 1)->get();

            if ($usersNonSyncdeleted) {

                foreach ($usersNonSyncdeleted as  $useridSupprime) {
                    // Vérifier si l'ID existe en ligne avant de le supprimer

                    $response = Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/users/' . $useridSupprime->id);



                    if ($response->successful()) {
                        // Supprimer le patient en ligne
                        $deleteResponse = Http::withHeaders($headers)->delete('https://api-medpay.akasigroup.net/api/users/' . $useridSupprime->id);
                        Log::info('Patient récupéré  effectué ');

                        if ($deleteResponse->successful()) {
                            $useridSupprime->is_synced = 1;
                            $useridSupprime->save();
                            Log::info('User supprimé en ligne avec succès. ID : ' . $useridSupprime->id);
                            // Supprimer l'ID de la liste après la suppression réussie

                        } else {
                            Log::error('Erreur lors de la suppression en ligne du patient. ID : ' . $useridSupprime->id);
                        }
                    } else {
                        Log::warning('Patient non trouvé en ligne. ID : ' . $useridSupprime);
                    }
                }
            }
        } else {
            Log::error('Internet connection is not available.');
        }
    }
}
