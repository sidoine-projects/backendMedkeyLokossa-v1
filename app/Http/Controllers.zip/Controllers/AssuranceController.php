<?php

namespace App\Http\Controllers;

use App\Models\Assurance;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Validation\Rule;


class AssuranceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $assurances = Assurance::orderBy('created_at', 'desc')->get();

        return response()->json([
            'success' => true,
            'data' => $assurances,
            'message' => 'Liste des assurances récupérée avec succès.'
        ]);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validation des données entrantes
        $validatedData = $request->validate([
            'nom' => 'required|string',
            // 'numero_assurance' => 'required|string',
            'numero_assurance' => 'required|string|min:8|unique:assurances',
            // 'montant' => 'required|numeric',
            'pourcentage' => 'required|numeric',
            'compagnie_d_assurance_id' => 'required|exists:compagnies_d_assurance,id',
        ]);

        // Création d'une nouvelle assurance
        $assurance = Assurance::create([
            'nom' => $validatedData['nom'],
            // 'montant' => $validatedData['montant'],
            'pourcentage' => $validatedData['pourcentage'],
            'compagnie_d_assurance_id' => $validatedData['compagnie_d_assurance_id'],
            'numero_assurance' => $validatedData['numero_assurance'],
        ]);

        if (!$assurance) {
            // En cas d'échec de création de l'assurance
            return response()->json([
                'success' => false,
                'message' => 'Échec de la création de l\'assurance.'
            ], 500);
        }

        // Réponse JSON avec les données de la nouvelle assurance
        return response()->json([
            'success' => true,
            'data' => $assurance,
            'message' => 'Assurance créée avec succès.'
        ], 201);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // Recherche de l'assurance par ID
        $assurance = Assurance::findOrFail($id);
        
      
        
        // L'assurance a été trouvée
        return response()->json([
            'success' => true,
            'data' => $assurance,
            'message' => 'OK'
        ]);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function update(Request $request, string $id)
    // {
    //     // Validation des données entrantes
    //     $validatedData = $request->validate([
    //         'nom' => 'required|string',
    //         // 'montant' => 'required|numeric',
    //         'pourcentage' => 'required|numeric',
    //         'compagnie_d_assurance_id' => 'required|exists:compagnies_assurance,id'
    //     ]);

    //     // Recherche de l'assurance par ID
    //     $assurance = Assurance::find($id);

    //     // Vérification si l'assurance existe
    //     if (!$assurance) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Assurance introuvable.'
    //         ], 404);
    //     }

    //     // Mise à jour des données de l'assurance
    //     $assurance->nom = $validatedData['nom'];
    //     // $assurance->montant = $validatedData['montant'];
    //     $assurance->pourcentage = $validatedData['pourcentage'];
    //     $assurance->compagnie_d_assurance_id = $validatedData['compagnie_d_assurance_id'];
    //     $assurance->save();

    //     // Réponse JSON avec les données mises à jour de l'assurance
    //     return response()->json([
    //         'success' => true,
    //         'data' => $assurance,
    //         'message' => 'Assurance mise à jour avec succès.'
    //     ]);
    // }
    public function update(Request $request, string $id)
    {
        // Validation des données entrantes
        $validatedData = $request->validate([
            'nom' => 'required|string',
            'pourcentage' => 'required|numeric',
            'compagnie_d_assurance_id' => 'required|exists:compagnies_d_assurance,id',
            // 'numero_assurance' => 'required|string',
            'numero_assurance' => 'required|string|unique:assurances',
            'numero_assurance' => ['required', 'string', Rule::unique('assurances')->ignore($id)],

        ]);

        try {
            // Recherche de l'assurance par ID
            $assurance = Assurance::findOrFail($id);

            // Mise à jour des données de l'assurance
            $assurance->nom = $validatedData['nom'];
            $assurance->pourcentage = $validatedData['pourcentage'];
            $assurance->compagnie_d_assurance_id = $validatedData['compagnie_d_assurance_id'];
            $assurance->numero_assurance = $validatedData['numero_assurance'];

            $assurance->save();

            // Réponse JSON avec les données mises à jour de l'assurance
            return response()->json([
                'success' => true,
                'data' => $assurance,
                'message' => 'Assurance mise à jour avec succès.'
            ]);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Assurance introuvable.'
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Une erreur s\'est produite lors de la mise à jour de l\'assurance.'
            ], 500);
        }
    }



    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(string $id)
    {
        // Recherche de l'assurance par ID
        $assurance = Assurance::find($id);

        // Vérification si l'assurance existe
        if (!$assurance) {
            return response()->json([
                'success' => false,
                'message' => 'Assurance introuvable.'
            ], 404);
        }

        // Suppression de l'assurance
        $assurance->delete();

        // Réponse JSON avec un message de succès
        return response()->json([
            'success' => true,
            'message' => 'Assurance supprimée avec succès.'
        ]);
    }



    public function getAssurancesByCompagnie(Request $request)

    {
        $compagnieId = $request->input('compagnieId');

        $assurances = Assurance::where('compagnie_d_assurance_id', $compagnieId)->get();

        return response()->json($assurances);
    }


    public function getPourcentageByAssurance($assuranceId)
    
    {
        $assurance = Assurance::find($assuranceId);

        if (!$assurance) {
            return response()->json(['error' => 'Assurance not found'], 404);
        }
        // return response()->json([
        //     'success' => true,
        //     'data' => [
        //         'pourcentage' => $assurance->pourcentage,
        //         'numero_assurance' => $assurance->numero_assurance,
        //     ],
        // ]);
         return response()->json([
           'pourcentage' => $assurance->pourcentage,
           'numero_assurance' => $assurance->numero_assurance,]);
    }



}
