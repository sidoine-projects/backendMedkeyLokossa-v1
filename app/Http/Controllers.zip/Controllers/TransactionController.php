<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;


class TransactionController extends Controller
{
    //
 
public function updateTransactionAmount(Request $request)
{
    $totalAmount = 0;

    if ($request->has('flexCheck1')) {
        $totalAmount += intval($request->input('flexCheck1'));
    }

    if ($request->has('flexCheck2')) {
        $totalAmount += intval($request->input('flexCheck2'));
    }

    if ($request->has('flexCheck3')) {
        $totalAmount += intval($request->input('flexCheck3'));
    }

    // Réinitialiser la valeur de la session
    Session::forget('transactionMontant');

    // Mettre à jour la valeur de la session avec la nouvelle valeur
    Session::put('transactionMontant', $totalAmount);

    return response()->json($totalAmount);
}
}
