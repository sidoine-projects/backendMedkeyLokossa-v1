<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use App\Models\Payement;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\Rule;

class PatientController extends Controller
{



    public function index()
    {
        $user = auth()->user();
        $roleId = $user->role_id;




        // Assurez-vous que l'utilisateur est associé à un centre
        if ($user->idcentre) {
            // Récupérez les patients associés au centre de l'utilisateur connecté

            $patients = Patient::where('centresanitaires_id', $user->idcentre)
                ->where('deleted_at', 0)
                ->latest()
                ->get();

            // return response()->json($patients);

        } else {
            return response()->json(['message' => 'Utilisateur non associé à un centre'], 403);
        }

        if ($roleId == 10 || $roleId == 1) {

            $patients = Patient::where('deleted_at', 0)
                ->latest()
                ->get();
        }

        return response()->json([
            'success' => true,
            'data' => $patients,
            'message' => 'Liste des patients du centre triée par ordre décroissant de la date de création.'
        ]);
    }


    /**
     * Store a newly created resource in storage.
     */
    // public function store(Request $request)
    // {
    //     //
    // }
    public function store(Request $request)
    {
        // Validation des données de la requête

        $validatedData = $request->validate([
            'nom' => 'required|string',
            'prenom' => 'required|string|alpha|min:2',
            'age' => 'required|numeric',
            'adresse' => 'required|string',
            'telephone' => [
                'required',
                'numeric',
                'digits:8',
                Rule::unique('patients', 'telephone')->where(function ($query) {
                    $query->where('deleted_at', 0);
                })->ignore(request()->input('id'), 'id')
                    ->where(function ($query) {
                        $query->where('whatsapp', request()->input('telephone'));
                    }),
            ],
            'email' => [
                'required',
                'email',
                Rule::unique('patients')->where(function ($query) {
                    $query->where('deleted_at', 0);
                }),
            ],
            'whatsapp' => [
                'required',
                'numeric',
                'digits:8',
                Rule::unique('patients')->where(function ($query) {
                    $query->where('deleted_at', 0);
                }),
            ],
            'profession' => 'required|string',
            'sexe' => 'required',
            'urgencecontact' => 'required|string',
            'autre' => 'nullable|string',
            'pays_id' => 'required|exists:pays,id',
            'departement_id' => 'required|exists:departements,id',
            'commune_id' => 'required|exists:communes,id',
            'centresanitaires_id' => 'exists:centresanitaires,id',
            'arrondissement_id' => 'required|exists:arrondissements,id',
            'quartier_id' => 'required|exists:quartiers,id',
            'situationmatrimoniale' => 'required|string',

        ]);

        // Récupérer l'ID de l'utilisateur connecté
        $userId = auth()->user();



        $patient = Patient::create([

            'is_synced' => 0,
            'user_id' => $userId->id, // Ajouter user_id
            'nom' => strtoupper($validatedData['nom']),
            'prenom' => ucfirst($validatedData['prenom']),
            'age' => $validatedData['age'],
            'adresse' => $validatedData['adresse'],
            'telephone' => $validatedData['telephone'],
            'email' => $validatedData['email'],
            'whatsapp' => $validatedData['whatsapp'],
            'profession' => $validatedData['profession'],
            'sexe' => $validatedData['sexe'],
            'urgencecontact' => $validatedData['urgencecontact'],
            'situationmatrimoniale' => $validatedData['situationmatrimoniale'],
            'pays_id' => $validatedData['pays_id'],
            'departement_id' => $validatedData['departement_id'],
            'commune_id' => $validatedData['commune_id'],
            'arrondissement_id' => $validatedData['arrondissement_id'],
            'quartier_id' => $validatedData['quartier_id'],
            'centresanitaires_id' => $userId->idcentre,
            'autre' => $validatedData['autre'],
            'deleted_at' => $request->input('deleted_at', 0), // Utilisation de la valeur par défaut 0 si 'deleted_at' n'est pas fourni

        ]);

        return response()->json([
            'success' => true,
            'data' => $patient,
            'message' => 'Patient créé avec succès.'
        ]);
    }


    function countPatients()
    {

        $user = auth()->user();
        $centreId = $user->idcentre;
        $roleId = $user->role_id;

        $count = Patient::where('patients.centresanitaires_id', $centreId)->where('patients.deleted_at', 0)->count();


        if ($roleId == 10 || $roleId == 1) {

            $count = Patient::count();
        }



        return response()->json([
            'success' => true,
            'message' => 'Nombre total de patient',
            'data' => $count

        ]);
    }


    /**
     * Display the specified resource.
     */



    public function show($id)
    {
        // Recherche du patient
        $patient = Patient::find($id);

        // Vérification si le patient existe
        if (!$patient) {
            return response()->json([
                'success' => false,
                'message' => 'Patient introuvable.'
            ], 404);
        }


        // Réponse JSON avec les données du patient
        return response()->json([
            'success' => true,
            'data' => $patient
        ]);
    }



    /**
     * Update the specified resource in storage.
     */

    public function update(Request $request, $id)
    {
        $user = auth()->user();

        // Mise à jour par ID

        $patient = Patient::find($id);

        $request->validate([
                      
            'nom' => 'required|string',
            'prenom' => 'required|string',
            'age' => 'required|numeric',
            'adresse' => 'required|string',
            'telephone' => [

                'required',
                'numeric',
                'digits:8',
                Rule::unique('patients', 'telephone')->where(function ($query) {
                    $query->where('deleted_at', 0);
                })->ignore($id, "id")
                    ->where(function ($query) use ($request) {
                        $query->where('whatsapp', $request->input('telephone'));
                }),

            ],

            'email' => [
                'required',
                'email',
                Rule::unique('patients', 'email')->where(function ($query) {
                    $query->where('deleted_at', 0);
                })->ignore($id),
            ],

            'whatsapp' => [
                'required',
                'numeric',
                'digits:8',

                Rule::unique('patients', 'whatsapp')->where(function ($query) {
                    $query->where('deleted_at', 0);
                })->ignore($id)
                 
            ],

            'profession' => 'required|string',
            'sexe' => 'required|string',
            'urgencecontact' => 'required|numeric',
            'situationmatrimoniale' => 'required|string',
            'pays_id' => 'required|exists:pays,id',
            'departement_id' => 'required|exists:departements,id',
            'commune_id' => 'required|exists:communes,id',
            'arrondissement_id' => 'required|exists:arrondissements,id',
            'quartier_id' => 'required|exists:quartiers,id',
            'autre' => 'nullable|string',

        ]);


        if (!$patient) {
            return response()->json([
                'success' => false,
                'message' => 'Patient introuvable.'
            ], 404);
        }

        $patient->is_synced = 0;
        $patient->user_id =  $user->id;
        $patient->nom = $request->input('nom');
        $patient->prenom = $request->input('prenom');
        $patient->email = $request->input('email');
        $patient->adresse = $request->input('adresse');
        $patient->age = $request->input('age');
        $patient->telephone = $request->input('telephone');
        $patient->whatsapp = $request->input('whatsapp');
        $patient->profession = $request->input('profession');
        $patient->urgencecontact = $request->input('urgencecontact');
        $patient->sexe = $request->input('sexe');
        $patient->autre = $request->input('autre');
        $patient->pays_id = $request->input('pays_id');
        $patient->departement_id = $request->input('departement_id');
        $patient->commune_id = $request->input('commune_id');
        $patient->arrondissement_id = $request->input('arrondissement_id');
        $patient->quartier_id = $request->input('quartier_id');
        $patient->situationmatrimoniale = $request->input('situationmatrimoniale');
        $patient->deleted_at = $request->input('deleted_at', 0);


        $patient->save();

        // Réponse JSON avec les données mises à jour du patient
        return response()->json([
            'success' => true,
            'data' => $patient, // Assurez-vous que les données du patient sont incluses ici
            'message' => 'Informations du patient mises à jour avec succès.'
        ], 200); // Vous pouvez également omettre le code de statut car 200 est le code par défaut.


    }



    public function destroy(string $id)
    {
        // Recherche du patient par ID

        $patient = Patient::find($id);

        // Vérification si le patient existe
        if (!$patient) {
            return response()->json([
                'success' => false,
                'message' => 'Patient introuvable.'
            ], 404);
        }

        $patient->update(['is_synced' => 0]);
        $patient->update(['deleted_at' => 1]);

        return response()->json([
            'success' => true,
            'message' => 'Patient supprimé avec succès.',


        ]);
    }

    public function getPaymentsByPatient($id)
    {
        $patient = Patient::find($id);

        if (!$patient) {
            return response()->json([
                'success' => false,
                'message' => 'Patient introuvable.'
            ], 404);
        }

        $payments = Payement::where('patient_id', $id)->get(); // Supposons que le champ 'patient_id' dans le modèle Payment représente l'ID du patient

        return response()->json([
            'success' => true,
            'data' => $payments,
            'message' => 'Paiements associés au patient récupérés avec succès.'
        ]);
    }


    public function synchroniserPatients()
    {

        // Récupérer l'utilisateur authentifié

        $accessToken = config('app.API_ACCESS_TOKEN');

        $url = 'http://www.google.com';

        $timeout = 5;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Vérifier le statut de la connexion Internet

        if ($httpCode == 200) {



            // $patientsNonSync = patient::where('is_synced', 0)->get();
            $patientsNonSync = Patient::where('is_synced', 0)->get();


            $headers = [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $accessToken,
            ];


            foreach ($patientsNonSync as $patient) {


                // $response = Http::get('https://api-medpay.akasigroup.net/api/patient/' . $patient->id);

                $response =  Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/patients/' . $patient->id);

                if ($response->successful()) {

                    Log::info('enregistrement trouvé ');


                    // Si le patient existe en ligne, mettre à jour les informations

                    $response =  Http::withHeaders($headers)->put('https://api-medpay.akasigroup.net/api/patients/' . $patient->id, $patient->toArray());

                    Log::info('Modification effectué ');
                } else {

                    // Sinon, si le patient est nouveau (n'a jamais été synchronisé), l'envoyer en ligne

                    $data = $patient->toArray();

                    $response = Http::withHeaders($headers)->post('https://api-medpay.akasigroup.net/api/patients', $data);
                }

                if ($response->successful()) {
                    // Mettre à jour le statut de synchronisation du patient en local
                    $patient->is_synced = 1;
                    $patient->save();
                    Log::info('patient synchronisé avec succès. id : ' . $patient->id);
                } else {

                    Log::error('Erreur lors de la synchronisation de l\'patient. id : ' . $patient->id . ' - Réponse API : ' . $response->json());
                }
            }


            $patientsNonSyncdeleted = Patient::where('is_synced', 0)->where('deleted_at', 1)->get();

            if ($patientsNonSyncdeleted) {

                foreach ($patientsNonSyncdeleted as  $patientidSupprime) {
                    // Vérifier si l'ID existe en ligne avant de le supprimer

                    $response = Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/patients/' . $patientidSupprime->id);



                    if ($response->successful()) {
                        // Supprimer le patient en ligne
                        $deleteResponse = Http::withHeaders($headers)->delete('https://api-medpay.akasigroup.net/api/patients/' . $patientidSupprime->id);
                        Log::info('Patient récupéré  effectué ');

                        if ($deleteResponse->successful()) {
                            $patientidSupprime->is_synced = 1;
                            $patientidSupprime->save();
                            Log::info('Patient supprimé en ligne avec succès. ID : ' . $patientidSupprime->id);
                            // Supprimer l'ID de la liste après la suppression réussie

                        } else {
                            Log::error('Erreur lors de la suppression en ligne du patient. ID : ' . $patientidSupprime->id);
                        }
                    } else {
                        Log::warning('Patient non trouvé en ligne. ID : ' . $patientidSupprime);
                    }
                }
            }
        } else {
            Log::error('Internet connection is not available.');
        }
    }
}
