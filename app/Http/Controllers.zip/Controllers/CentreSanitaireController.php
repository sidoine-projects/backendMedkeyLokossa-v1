<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CentreSanitaire;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;

class CentreSanitaireController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $centresSanitaires = CentreSanitaire::orderBy('created_at', 'desc')->get();

        // return response()->json([
        //     'success' => true,
        //     'data' => $centresSanitaires,
        //     'message' => 'Liste des centres sanitaires.'
        // ]);
        // 222222222222222222
        $user = Auth::user(); // Supposons que vous utilisez Laravel pour la gestion de l'authentification

        if ($user->hasRole('Directeur')) {
            $centreSanitaire = CentreSanitaire::find($user->idcentre);

            if ($centreSanitaire) {
                return response()->json([
                    'success' => true,
                    'data' => [$centreSanitaire],
                    'message' => 'Centre sanitaire de l\'utilisateur connecté.'
                ]);
            }
        } else {
            $centresSanitaires = CentreSanitaire::orderBy('created_at', 'desc')->get();
            return response()->json([
                'success' => true,
                'data' => $centresSanitaires,
                'message' => 'Liste des centres sanitaires.'
            ]);
        }

        // Si l'utilisateur n'est pas un Directeur ou n'est pas associé à un centre
        return response()->json([
            'success' => false,
            'message' => 'L\'utilisateur n\'a pas accès aux centres sanitaires.'
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { {
            $request->validate([
                'nom' => 'required|string',
                'departement_id' => 'required|exists:departements,id',
                'commune_id' => 'required|exists:communes,id',
                'arrondissement_id' => 'required|exists:arrondissements,id',
                'quartier_id' => 'required|exists:quartiers,id',
                'adresse' => 'required|string',
                'telephone' => 'required|string|min:8',
                'email' => 'required|string|email',
                'idtypecentresanitaire' => 'required|integer',
                'directeur' => 'required|string',
                // 'reference' => 'required|string',
                'reference' => 'required|string|unique:centresanitaires,reference,',

            ]);

            $centreSanitaire = CentreSanitaire::create([
                'nom' => $request->nom,
                'departement_id' => $request->departement_id,
                'commune_id' => $request->commune_id,
                'arrondissement_id' => $request->arrondissement_id,
                'quartier_id' => $request->quartier_id,
                'adresse' => $request->adresse,
                'telephone' => $request->telephone,
                'email' => $request->email,
                'idtypecentresanitaire' => $request->idtypecentresanitaire,
                'directeur' => $request->directeur,
                'reference' => $request->reference,
            ]);

            return response()->json($centreSanitaire, 201);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {


        $centreSanitaire = CentreSanitaire::find($id);



        return response()->json($centreSanitaire);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'nom' => 'required|string',
            'departement_id' => 'required|exists:departements,id',
            'commune_id' => 'required|exists:communes,id',
            'arrondissement_id' => 'required|exists:arrondissements,id',
            'quartier_id' => 'required|exists:quartiers,id',
            'adresse' => 'required|string',
            'telephone' => 'required|string',
            'email' => 'required|string|email',
            'idtypecentresanitaire' => 'required|integer',
            'directeur' => 'required|string',


            'reference' => ['required', 'string', Rule::unique('centresanitaires')->ignore($id, "id")],

            // Rule::unique('articles')->ignore(intval(CentreSanitaire::find($id), 'id')
        ]);

        $centreSanitaire = CentreSanitaire::find($id);


        $centreSanitaire->nom = $request->input('nom');
        $centreSanitaire->departement_id = $request->input('departement_id');
        $centreSanitaire->commune_id = $request->input('commune_id');
        $centreSanitaire->arrondissement_id = $request->input('arrondissement_id');
        $centreSanitaire->quartier_id = $request->input('quartier_id');
        $centreSanitaire->adresse = $request->input('adresse');
        $centreSanitaire->telephone = $request->input('telephone');
        $centreSanitaire->email = $request->input('email');
        $centreSanitaire->idtypecentresanitaire = $request->input('idtypecentresanitaire');
        $centreSanitaire->directeur = $request->input('directeur');
        $centreSanitaire->reference = $request->input('reference');

        $centreSanitaire->save();

        return response()->json(['message' => 'Centre sanitaire mis à jour avec succès']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $centreSanitaire = CentreSanitaire::find($id);

        $centreSanitaire->delete();

        return response()->json(['message' => 'Centre sanitaire supprimé avec succès']);
    }


    public function getCentreByReference(Request $request)
    {
        $reference = $request->input('reference');

        $centre = CentreSanitaire::where('reference', $reference)->first();

        if (!$centre) {
            return response()->json(['error' => 'Le centre avec la référence spécifiée n\'existe pas'], 404);
        }

        return response()->json($centre, 200);
    }
}
