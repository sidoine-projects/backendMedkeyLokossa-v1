<?php

namespace App\Http\Controllers;

use App\Models\Indigence;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;


class IndigenceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        
        $indigences = Indigence::orderBy('created_at', 'desc')->get();

        return response()->json([
            'success' => true,
            'data' => $indigences,
            'message' => 'Liste des indigences récupérée avec succès.'
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();


        if (!isset($data['forms'])) {
            return response()->json([
                'success' => false,
                'message' => 'Le champ "forms" est requis.',
            ], 400);
        }

        $forms = $data['forms'];
        $indigence = [];

        foreach ($forms as $form) {
            $validatedData = Validator::make($form, [
                'agemin' => 'required|integer',
                'agemax' => 'required|integer',
                'pourcentage' => 'required|numeric',
                'observation' => 'nullable|string',
            ])->validate();

            $indigence = Indigence::create([
                'agemin' => $validatedData['agemin'],
                'agemax' => $validatedData['agemax'],
                'pourcentage' => $validatedData['pourcentage'],
                'observation' => $validatedData['observation'],
            ]);

            $indigences[] = $indigence;
        }

        return response()->json([
            'success' => true,
            'message' => 'Indigence enregistrée avec succès.',
            'data' => $indigences,
        ], 201);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(string $id)
    {
        // Recherche de l'indigence par ID
        $indigence = Indigence::find($id);

        // Vérification si l'indigence existe
        if (!$indigence) {
            return response()->json([
                'success' => false,
                'message' => 'Indigence introuvable.'
            ], 404);
        }

        // Réponse JSON avec les données de l'indigence
        return response()->json([
            'success' => true,
            'data' => $indigence,
            'message' => 'ok'
        ]);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, string $id)
    {
        // Validation des données entrantes
        $validatedData = $request->validate([
            'agemin' => 'required|integer',
            'agemax' => 'required|integer',
            'pourcentage' => 'required|numeric',
            'observation' => 'nullable|string'
        ]);

        // Recherche de l'indigence par ID
        $indigence = Indigence::find($id);

        // Vérification si l'indigence existe
        if (!$indigence) {
            return response()->json([
                'success' => false,
                'message' => 'Indigence introuvable.'
            ], 404);
        }

        // Mise à jour des données de l'indigence
        $indigence->agemin = $validatedData['agemin'];
        $indigence->agemax = $validatedData['agemax'];
        $indigence->pourcentage = $validatedData['pourcentage'];
        $indigence->observation = $validatedData['observation'];
        $indigence->save();

        // Réponse JSON avec les données mises à jour de l'indigence
        return response()->json([
            'success' => true,
            'data' => $indigence,
            'message' => 'Indigence mise à jour avec succès.'
        ]);
    }

    // public function update(Request $request, $id)
    // {
    //     $data = $request->all();

    //     if (!isset($data['forms'])) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Le champ "forms" est requis.',
    //         ], 400);
    //     }

    //     $forms = $data['forms'];
    //     $indigences = [];

    //     foreach ($forms as $form) {
    //         $validatedData = Validator::make($form, [
    //             'agemin' => 'required|integer',
    //             'agemax' => 'required|integer',
    //             'pourcentage' => 'required|numeric',
    //             'observation' => 'nullable|string',
    //         ])->validate();

    //         $indigence = Indigence::find($id);

    //         $indigence->agemin = $validatedData['agemin'];
    //         $indigence->agemax = $validatedData['agemax'];
    //         $indigence->pourcentage = $validatedData['pourcentage'];
    //         $indigence->observation = $validatedData['observation'];

    //         $indigence->save();

    //         $indigences[] = $indigence;
    //     }

    //     return response()->json([
    //         'success' => true,
    //         'message' => 'Indigence mise à jour avec succès.',
    //         'data' => $indigences,
    //     ], 200);
    // }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(string $id)
    {
        // Recherche de l'indigence par ID
        $indigence = Indigence::find($id);

        // Vérification si l'indigence existe
        if (!$indigence) {
            return response()->json([
                'success' => false,
                'message' => 'Indigence introuvable.'
            ], 404);
        }

        // Suppression de l'indigence
        $indigence->delete();

        // Réponse JSON avec un message de succès
        return response()->json([
            'success' => true,
            'message' => 'Indigence supprimée avec succès.'
        ]);
    }
}
