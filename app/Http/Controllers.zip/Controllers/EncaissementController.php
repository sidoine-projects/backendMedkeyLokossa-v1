<?php

namespace App\Http\Controllers;

use App\Models\Encaissement;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;

use Laravel\Sanctum\PersonalAccessToken;

class EncaissementController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Récupérer l'ID de l'utilisateur connecté
        // $userId = auth()->user()->id;

        $user = auth()->user();
        $centreId = $user->idcentre;

        $roleId = $user->role_id;


        $encaissements = Encaissement::where('encaissement_centre_id', $centreId)->orderByDesc('id')->get();

        if ($roleId == 10 || $roleId == 1) {

            $encaissements = Encaissement::orderByDesc('id')->get();


        }


        // Réponse JSON avec les actes médicaux de l'utilisateur

        return response()->json([
            'success' => true,
            'data' => $encaissements,
            'message' => 'Liste des encaissements de l\'utilisateur.'
        ]);
    }


    public function getMontantParMois()
    {
        $montants = Encaissement::getMontantParMois();

        return response()->json(
            [
                'success' => true,
                'message' => 'Encaissement de chaque mois:',
                'data' =>   $montants
            ]
        );
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $user = auth()->user();
        $centreId = $user->idcentre;
        $validatedData = $request->validate([
            'adresse' => 'required|string',
            'name' => 'required|string',
            'description' => 'required|string',
            'telephone' => 'required|string',
            'email' => 'required|email',
            'libelle' => 'required|string',
            'montant' => 'required|string',
            'mode_id' => 'required'
            // 'user_id' => 'required|exists:users,id',
        ]);


        $id = $request->input('id');


        $encaissement = Encaissement::create([

            'is_synced' => 0, // Marquer comme non synchronisé
            'adresse' => $validatedData['adresse'],
            'name' => $validatedData['name'],
            'description' => $validatedData['description'],
            'telephone' => $validatedData['telephone'],
            'email' => $validatedData['email'],
            'libelle' => $validatedData['libelle'],
            'montant' => $validatedData['montant'],
            'mode_id' => $validatedData['mode_id'],
            'encaissement_user_id' => $user->id,
            'encaissement_centre_id' =>  $centreId

            // 'user_id' => $userId, // Ajouter user_id
        ]);

        return response()->json([
            'success' => true,
            'data' => $encaissement,
            'message' => 'Encaissement enregistré avec succès.'
        ]);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'adresse' => 'required|string',
            'name' => 'required|string',
            'description' => 'required|string',
            'telephone' => 'required|string',
            'email' => 'required|email',
            'libelle' => 'required|string',
            'montant' => 'required|string',
            'mode_id' => 'required'
        ]);

        $user = auth()->user();
        $encaissement = Encaissement::find($id);

        if (!$encaissement) {
            $encaissement = Encaissement::where('id', $id)->first();
        }


        if (!$encaissement) {
            return response()->json([
                'success' => false,
                'message' => 'Introuvable.'
            ], 404);
        }

        $encaissement->is_synced = 0;
        $encaissement->name = $request->input('name');
        $encaissement->adresse = $request->input('adresse');
        $encaissement->description = $request->input('description');
        $encaissement->telephone = $request->input('telephone');
        $encaissement->email = $request->input('email');
        $encaissement->libelle = $request->input('libelle');
        $encaissement->montant = $request->input('montant');
        $encaissement->mode_id = $request->input('mode_id');
        $encaissement->encaissement_user_id =  $user->id;



        $encaissement->save();

        return response()->json(['message' => 'Encaissement mis à jour avec succès']);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        // Recherche de l'acte médical par ID
        $encaissement = Encaissement::find($id);

        // Si l'encaissement n'est pas trouvé par ID numérique, recherche par id
        if (!$encaissement) {

            $encaissement = Encaissement::where('id', $id)->first();
        }


        // Vérification si l'acte médical existe
        if (!$encaissement) {
            return response()->json([
                'success' => false,
                'message' => 'Introuvable.'
            ], 404);
        }
        return response()->json([
            'success' => true,
            'data' => $encaissement,
            'message' => 'Détails de l\'encaissement récupérés avec succès.'
        ]);
    }


    /**
     * Update the specified resource in storage.
     */

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Encaissement $encaissement)
    {
        //
    }



    public function synchroniserEncaissements()
    {

        // Récupérer l'utilisateur authentifié

        $accessToken = config('app.API_ACCESS_TOKEN');


        // Vérification de la connexion Internet
        $url = 'http://www.google.com';
        $timeout = 5;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Vérifier le statut de la connexion Internet
        if ($httpCode == 200) {

            // Récupérer les Encaissements non synchronisés et mis à jour localement
            $encaissementsNonSync = Encaissement::where('is_synced', 0)->get();

            $headers = [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $accessToken,
            ];

            foreach ($encaissementsNonSync as $encaissement) {


                $response =  Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/encaissement/' . $encaissement->id);

                if ($response->successful()) {
                    Log::info('enregistrement trouvé ');

                    // Si le encaissement existe en ligne, mettre à jour les informations

                    $response =  Http::withHeaders($headers)->put('https://api-medpay.akasigroup.net/api/encaissement/' . $encaissement->id, $encaissement->toArray());

                    Log::info($response->json());
                } else {
                    // Sinon, si le encaissement est nouveau (n'a jamais été synchronisé), l'envoyer en ligne
                    $data = $encaissement->toArray();

                    $response = Http::withHeaders($headers)->post('https://api-medpay.akasigroup.net/api/encaissement', $data);
                }

                if ($response->successful()) {
                    // Mettre à jour le statut de synchronisation du encaissement en local
                    $encaissement->is_synced = 1;
                    $encaissement->save();
                    Log::info('Encaissement synchronisé avec succès. id : ' . $encaissement->id);
                } else {

                    Log::error('Erreur lors de la synchronisation de l\'encaissement. id : ' . $encaissement->id . ' - Réponse API : ' . $response->json());
                }
            }
        } else {
            Log::error('Internet connection is not available.');
        }
    }



}
