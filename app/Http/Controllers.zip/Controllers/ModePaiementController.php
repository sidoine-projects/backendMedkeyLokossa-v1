<?php

namespace App\Http\Controllers;

use App\Models\TypeModePaiement;
use Illuminate\Http\Request;

class ModePaiementController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $modes = TypeModePaiement::all();
        return response()->json([
            'success' => true,
            'data' => $modes,
            'message' => 'Liste des modes de paiements.'
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            // Ajoutez d'autres règles de validation pour les autres champs si nécessaire
        ]);

        $mode = new TypeModePaiement();
        $mode->name = $request->input('name');

        $mode->save();

        return response()->json([
            'success' => true,
            'data' => $mode,
            'message' => 'Le mode a été créé avec succès.'
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $mode = TypeModePaiement::find($id);

        return response()->json([
            'success' => true,
            'data' => $mode,
            'message' => 'Détails du mode.'
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $mode = TypeModePaiement::find($id);

        // Valider les données du formulaire
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            // Ajoutez ici les autres règles de validation pour les autres champs du modèle mode
        ]);

        // Mettre à jour les propriétés du modèle mode avec les données validées
        $mode->name = $validatedData['name'];
        // Mettez à jour ici les autres propriétés du modèle mode avec les données validées

        // Enregistrer les modifications dans la base de données
        $mode->save();

        return response()->json([
            'success' => true,
            'data' => $mode,
            'message' => 'Mode mis à jour avec succès.'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $mode = TypeModePaiement::find($id);

        // Supprimer le mode de la base de données
        $mode->delete();

        return response()->json([
            'success' => true,
            'message' => 'Pays supprimé avec succès.'
        ]);
    }
}
