<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Auth;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    // public function index()
    // {
    // //     //
    //      $roles = Role::all();

    //     $response = [
    //         'success' => true,
    //         'data' => $roles,
    //         'message' => 'Liste des rôles.'
    //     ];

    //     return response()->json($response);
    // }

    public function index()
    {
        // $roles = Role::all();
        // $response = [
        //     'success' => true,
        //     'data' => $roles,
        //     'message' => 'Liste des rôles.'
        // ];


        // return response()->json($response);

        // Récupérer l'utilisateur authentifié
        $user = Auth::user();

        // Récupérer le rôle "super_admin"
        $superAdminRole = Role::where('name', 'Super_admin')->first();

        // Récupérer le rôle "admin"
        $adminRole = Role::where('name', 'Admin')->first();

        // Récupérer le rôle "directeur"
        $directeurRole = Role::where('name', 'Directeur')->first();

        // Récupérer tous les rôles
        $roles = Role::all();
      
        // $roles = Role::orderBy('created_at', 'desc')->get();


        // Vérifier si l'utilisateur a le rôle "super_admin"
        if ($user->role_id === $superAdminRole->id) {
            // Si c'est le cas, renvoyer la liste complète des rôles
            $response = [
                'success' => true,
                'data' => $roles,
                'message' => 'Liste des rôles.'
            ];
        } elseif ($user->role_id === $adminRole->id) {
            // Si l'utilisateur a le rôle "admin", filtrer les rôles pour exclure "super_admin"
            // Si l'utilisateur a le rôle "Directeur", filtrer les rôles pour exclure "admin" et "super_admin"
            $filteredRoles = $roles->reject(function ($role) use ($adminRole, $superAdminRole) {
                return $role->id === $adminRole->id || $role->id === $superAdminRole->id;
            });

            $response = [
                'success' => true,
                'data' => $filteredRoles,
                'message' => 'Liste des rôles (sauf super_admin).'
            ];
        }
        // elseif ($user->role_id === $directeurRole->id) {
        //     // Si l'utilisateur a le rôle "Directeur", filtrer les rôles pour exclure "admin" et "super_admin"
        //     $filteredRoles = $roles->reject(function ($role) use ($adminRole, $superAdminRole) {
        //         return $role->id === $adminRole->id || $role->id === $superAdminRole->id;
        //     });

        //     $response = [
        //         'success' => true,
        //         'data' => $filteredRoles,
        //         'message' => 'Liste des rôles (sauf admin et super_admin).'
        //     ];
        // } 
        elseif ($user->role_id === $directeurRole->id) {
            // Si l'utilisateur a le rôle "Directeur", exclure les rôles "admin", "super_admin" et "directeur"
            $filteredRoles = $roles->reject(function ($role) use ($adminRole, $superAdminRole, $directeurRole) {
                return $role->id === $adminRole->id || $role->id === $superAdminRole->id || $role->id === $directeurRole->id;
            });

            $response = [
                'success' => true,
                'data' => $filteredRoles,
                'message' => 'Liste des rôles (sauf admin, super_admin et directeur).'
            ];
        } else {
            // Si l'utilisateur a un autre rôle, renvoyer une erreur ou un message approprié
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Accès non autorisé.'
            ];
        }

        return response()->json($response);
    }




    public function droitUsers(Request $request)
    {
        // dd("data", $request);
        $role = Role::find($request->id);

        foreach ($request->permissions as $permission) {
            $permissions = Permission::find($permission);
            $role->givePermissionTo($permissions);
            // $permission->assignRole($role);
        }
        // // Réponse JSON avec les données du rôle
        return response()->json([
            'success' => true,
            'data' => $role
        ]);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string',
            'description' => 'required|string',
        ]);


        $role = Role::create([
            'name' => $validatedData['name'],
            'description' =>  $validatedData['description'],
        ]);

        $response = [
            'success' => true,
            'data' => $role,
            'message' => 'Rôle créé avec succès.'
        ];

        return response()->json($response);
    }


    public function show($id)
    {
        // Recherche du rôle
        $role = Role::find($id);

        // Vérification si le rôle existe
        if (!$role) {
            return response()->json([
                'success' => false,
                'message' => 'Rôle introuvable.'
            ], 404);
        }

        // Réponse JSON avec les données du rôle
        return response()->json([
            'success' => true,
            'data' => $role
        ]);
    }


    /**
     * Update the specified resource in storage.
     */
    // public function update(Request $request, Role $role)
    // {
    //     //
    // }
    public function update(Request $request, $id)
    {
        // Validation des données entrantes
        $validatedData = $request->validate([
            'name' => 'required|string',
            'description' => 'required|string',
        ]);

        // Recherche du rôle à mettre à jour
        $role = Role::find($id);

        // Vérification si le rôle existe
        if (!$role) {
            return response()->json([
                'success' => false,
                'message' => 'Rôle introuvable.'
            ], 404);
        }

        // Mise à jour des données du rôle
        $role->name = $validatedData['name'];
        $role->description = $validatedData['description'];
        $role->save();

        // Réponse JSON avec les données mises à jour du rôle
        return response()->json([
            'success' => true,
            'data' => $role,
            'message' => 'Rôle mis à jour avec succès.'
        ]);
    }



    /**
     * Remove the specified resource from storage.
     */
    // public function destroy(Role $role)
    // {
    //     //
    // }
    public function destroy($id)
    {
        // Recherche du rôle à supprimer
        $role = Role::find($id);

        // Vérification si le rôle existe
        if (!$role) {
            return response()->json([
                'success' => false,
                'message' => 'Rôle introuvable.'
            ], 404);
        }

        // Suppression du rôle
        $role->delete();

        // Réponse JSON avec un message de succès
        return response()->json([
            'success' => true,
            'message' => 'Rôle supprimé avec succès.'
        ]);
    }

    public function getPermissionsForRole($roleId)
    {
        try {
            $role = Role::with('permissions')->findOrFail($roleId);

            $permissions = $role->permissions;

            return response()->json($permissions, 200);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Une erreur s\'est produite.'], 500);
        }
    }
}
