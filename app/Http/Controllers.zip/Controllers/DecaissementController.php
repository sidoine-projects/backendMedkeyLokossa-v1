<?php

namespace App\Http\Controllers;

use App\Models\Decaissement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use CURLFile;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;



class DecaissementController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $user = auth()->user();
        $centreId = $user->idcentre;

        $roleId = $user->role_id;

        $decaissements = Decaissement::where('decaissement_centre_id', $centreId)->orderByDesc('id')->get();

        if ($roleId == 10 || $roleId == 1) {

            $decaissements = Decaissement::orderByDesc('id')->get();


        }

        // Réponse JSON avec les actes médicaux de l'utilisateur
        return response()->json([
            'success' => true,
            'data' => $decaissements,
            'message' => 'Liste des décaissements de l\'utilisateur.'
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $user = auth()->user();
        $centreId = $user->idcentre;
        $validatedData = $request->validate([
            'motif' => 'required|string',
            'montant' => 'required|string',
            'description' => 'required|string',
            'facture' => 'file|max:2048',
            // 'user_id' => 'required|exists:users,id',
        ]);

        $file = $request->file('facture');
        $originalName = $file->getClientOriginalName();

        $extension = $file->getClientOriginalExtension();
        $fileName = time() . '_' . $originalName;

        // Définir le répertoire de destination pour la facture
        $destinationPath = base_path('factures');

        // Déplacer le fichier vers le répertoire de destination
        $file->move($destinationPath, $fileName);

        // Récupérer le chemin complet du fichier sauvegardé
        $filePath = $destinationPath . '/' . $fileName;

        // Créer l'instance de Decaissement avec les données validées
        $data = Decaissement::create([

            'is_synced' => 0, // Marquer comme non synchronisé
            'motif' => $validatedData['motif'],
            'montant' => $validatedData['montant'],
            'description' => $validatedData['description'],
            'facture' => $fileName,
            'decaissement_user_id' => $user->id,
            'decaissement_centre_id' =>  $centreId
            // 'user_id' => $userId, // Ajouter user_id

        ]);

        return response()->json([
            'success' => true,
            'data' => $data,
            'message' => 'Décaissement enregistré avec succès.'
        ]);
    }



    function getTotaldecaisse()
    {

        $user = auth()->user();
        $centreId = $user->idcentre;
        $roleId = $user->role_id;

        $dateActuelle = Carbon::now()->toDateString();

        $totaldecaissement = DB::table('decaissements')
        ->whereDate('created_at', $dateActuelle)
        ->where('decaissements.decaissement_centre_id', $centreId)
        ->sum('montant');

        if ($roleId == 10 || $roleId == 1) {

            $totaldecaissement = DB::table('decaissements')
                ->whereDate('created_at', $dateActuelle)
                ->sum('montant');
        }



        return response()->json([
            'success' => true,
            'message' => 'Decaissement de la date actuelle est:',
            'data' =>  $totaldecaissement
        ]);
    }

    public function getMontantParMois()
    {
        $montants = Decaissement::getMontantParMois();

        return response()->json(
            [
                'success' => true,
                'message' => 'Decaissement de chaque mois:',
                'data' =>   $montants
            ]
        );
    }


    public function showFile($id)
    {
        $decaissement = Decaissement::find($id);

        if (!$decaissement) {
            return response()->json([
                'success' => false,
                'message' => 'Le décaissement n\'existe pas.'
            ], 404);
        }

        $fileName = $decaissement->facture;
        $filePath = base_path('factures/' . $fileName);

        if (file_exists($filePath)) {
            return response()->file($filePath);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Le fichier de la facture n\'existe pas.'
            ], 404);
        }
    }



    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $decaissement = Decaissement::find($id);

        // Vérification si l'acte médical existe
        if (!$decaissement) {
            return response()->json([
                'success' => false,
                'message' => 'Introuvable.'
            ], 404);
        }
        return response()->json([
            'success' => true,
            'data' => $decaissement,
            'message' => 'Détails du décaissement récupérés avec succès.'
        ]);
    }

    public function updateFile(Request $request, $id)
    {
        // $validateData = $request->validate([
        //     'facture' => 'file|mimes:pdf,doc,docx|max:2048',
        // ])
        $decaissement = Decaissement::findOrFail($id);

        if ($request->facture != $decaissement->facture) {
            if ($request->hasFile('facture')) {
                $file = $request->file('facture');
                $originalName = $file->getClientOriginalName();

                $extension = $file->getClientOriginalExtension();
                $fileName = time() . '_' . $originalName;

                // Déplacer le nouveau fichier vers le répertoire de stockage
                $filePath = $file->storeAs('factures', $fileName);

                // Supprimer l'ancien fichier s'il existe
                if ($decaissement->facture) {
                    Storage::delete('factures/' . $decaissement->facture);
                }
                // Mettre à jour le nom du fichier dans la base de données
                $decaissement->facture = $fileName;
                $decaissement->save();

                return response()->json([
                    'satusCode' => 200,
                    'message' => 'Fichier modifier',
                    'date' => $fileName
                ]);
            }
        }




        return response()->json([
            'satusCode' => 500,
            'message' => 'Fichier non modifié',
        ]);
    }

    /**
     * Update the specified resource in storage.
     */

    public function update(Request $request, $id)
    {
        $decaissement = Decaissement::findOrFail($id);

        $validatedData = $request->validate([
            'motif' => 'required|string',
            'montant' => 'required|string',
            'description' => 'required|string',

        ]);



        // Mettre à jour les autres champs du décaissement avec les données validées
        $decaissement->is_synced = 0;
        $decaissement->motif = $request->motif;
        $decaissement->montant = $request->montant;
        $decaissement->description = $request->description;

        if ($request->facture != $decaissement->facture) {
            $validatedData = $request->validate([
                'facture' => 'file|max:2048',

            ]);
            if ($request->hasFile('facture')) {
                $file = $request->file('facture');
                $originalName = $file->getClientOriginalName();

                $extension = $file->getClientOriginalExtension();
                $fileName = time() . '_' . $originalName;

                // Déplacer le nouveau fichier vers le répertoire de stockage
                $filePath = $file->storeAs('factures', $fileName);

                // Supprimer l'ancien fichier s'il existe
                if ($decaissement->facture) {
                    Storage::delete('factures/' . $decaissement->facture);
                }
                // Mettre à jour le nom du fichier dans la base de données
                $decaissement->facture = $fileName;

                // return response()->json([
                //     'satusCode' => 200,
                //     'message' => 'Fichier modifier',
                //     'date' => $fileName
                // ]);
            }
        }
        // $decaissement->facture = 'text';

        $decaissement->save();

        return response()->json([
            'success' => true,
            'data' => $decaissement,
            'message' => 'Décaissement mis à jour avec succès.'
        ]);
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Decaissement $decaissement)
    {
        //
    }




    public function storeDecaissement(Request $request)
    {


        // Ajouter un nouveau décaissement

        $data = [

            'is_synced' => 0, // Marquer comme non synchronisé
            'motif' => $request->motif,
            'montant' => $request->montant,
            'description' => $request->description,
            'facture' =>  $request->facture,
            'decaissement_user_id' => $request->decaissement_user_id,
            'decaissement_centre_id' => $request->decaissement_centre_id
        ];

        $decaissement = Decaissement::create($data);



        return response()->json([
            'success' => true,
            'data' => $decaissement,
            'message' => 'Décaissement enregistré avec succès.'
        ]);
    }

    public function UpdateOnlinDecaissement(Request $request, $id)
    {

        $decaissement = Decaissement::findOrFail($id);


        $decaissement->motif = $request->input('motif');
        $decaissement->montant = $request->input('montant');
        $decaissement->description = $request->input('description');
        $decaissement->facture = $request->input('facture');
        $decaissement->decaissement_user_id = $request->input('decaissement_user_id');
        $decaissement->decaissement_centre_id = $request->input('decaissement_centre_id');
        $decaissement->is_synced = 0;


        $decaissement->save();


        return response()->json([
            'success' => true,
            'data' => $decaissement,
            'message' => 'Décaissement enregistré avec succès.'
        ]);
    }



    public function synchroniserDecaissements()
    {

        // Récupérer l'utilisateur authentifié

        $accessToken = config('app.API_ACCESS_TOKEN');


        // Vérification de la connexion Internet
        $url = 'http://www.google.com';
        $timeout = 5;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Vérifier le statut de la connexion Internet
        if ($httpCode == 200) {

            // Récupérer les decaissements non synchronisés et mis à jour localement
            $decaissementsNonSync = Decaissement::where('is_synced', 0)->get();

            $headers = [

                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $accessToken,
            ];

            foreach ($decaissementsNonSync as $decaissement) {


                $response =  Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/decaissement/' . $decaissement->id);


                if ($response->successful()) {
                    Log::info('enregistrement trouvé ');

                    // Si le decaissement existe en ligne, mettre à jour les informations


                    $response =  Http::withHeaders($headers)->put('https://api-medpay.akasigroup.net/api/decaissement/' . $decaissement->id, $decaissement->toArray());


                    // $response = Http::withHeaders($headers)->put('https://api-medpay.akasigroup.net/api/storedecaissement/' . $decaissement->id, $decaissement->toArray());

                    Log::info($response->json());
                } else {
                    // Sinon, si le decaissement est nouveau (n'a jamais été synchronisé), l'envoyer en ligne
                    $remoteDecaissementUrl = 'https://api-medpay.akasigroup.net/api/storedecaissement';

                    $data = $decaissement->toArray();


                    // Envoi de la requête à l'API avec les données et le fichier attaché
                    $response =  Http::withHeaders($headers)->post('https://api-medpay.akasigroup.net/api/storedecaissement',   $data);
                }

                if ($response->successful()) {
                    // Marquer comme synchronisé localement
                    $decaissement->is_synced = 1;
                    $decaissement->save();

                    Log::info('Decaissement synchronisé avec succès. id : ' . $decaissement->facture);
                } else {

                    Log::info('Échec de la synchronisation. : ' . $decaissement->facture);
                }
            }
        } else {

            Log::error('Internet connection is not available.');
        }
    }
}
