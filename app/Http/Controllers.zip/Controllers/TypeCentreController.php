<?php

namespace App\Http\Controllers;

use App\Models\TypeCentre;
use Illuminate\Http\Request;

class TypeCentreController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $typeCentre = TypeCentre::latest()->get();
        return response()->json([
            'success' => true,
            'data' => $typeCentre,
            'message' => 'Liste des types des centres.'
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nom' => 'required|string',
            // Ajoutez d'autres règles de validation pour les autres champs si nécessaire
        ]);

        $typeCentre = new TypeCentre();
        $typeCentre->nom = $request->input('nom');

        // Enregistrez le pays dans la base de données
        $typeCentre->save();

        return response()->json([
            'success' => true,
            'data' => $typeCentre,
            'message' => 'Le type de centre a été créé avec succès.'
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {

        $typeCentre = TypeCentre::find($id);

        return response()->json([
            'success' => true,
            'data' => $typeCentre,
            'message' => 'Détails du type de centres.'
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $typeCentre = TypeCentre::find($id);

        // Valider les données du formulaire
        $validatedData = $request->validate([
            'nom' => 'required|string|max:255',
            // Ajoutez ici les autres règles de validation pour les autres champs du modèle Pays
        ]);

        // Mettre à jour les propriétés du modèle Pays avec les données validées
        $typeCentre->nom = $validatedData['nom'];
        // Mettez à jour ici les autres propriétés du modèle Pays avec les données validées

        // Enregistrer les modifications dans la base de données
        $typeCentre->save();

        return response()->json([
            'success' => true,
            'data' => $typeCentre,
            'message' => 'Le type de centre a été mis à jour avec succès.'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $typeCentre = TypeCentre::find($id);

        // Supprimer le pays de la base de données
        $typeCentre->delete();

        return response()->json([
            'success' => true,
            'message' => 'Type centre supprimé avec succès.'
        ]);
    }
}