<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Facture;
use App\Models\Espece;
use App\Models\Patient;
use App\Models\Momo;
use App\Models\Fedapay;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Validator;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Support\Facades\DB;
use App\Models\CentreSanitaire;
use App\Models\Terminal;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;


use SimpleSoftwareIO\QrCode\Facades\QrCode;


class FactureController extends Controller
{

    use HasRoles;

    public function store(Request $request, $payementId)
    {
        $data = $request->all();

        $user = $request->user();

        $annee = date('y');
        $mois = date('m');
        $jour = date('d');

        // Générer un code aléatoire de 8 chiffres
        $codeAleatoire = mt_rand(10000000, 99999999);

        // Concaténer les éléments pour former le code unique de la facture
        $codeUnique = $annee . $mois . $jour . '-' . $codeAleatoire;

        // Vérifier si le code généré est déjà utilisé (assurez-vous d'avoir une colonne unique pour le code dans la table)
        while (Facture::where('code', $codeUnique)->exists()) {
            // Générer un nouveau code aléatoire de 8 chiffres
            $codeAleatoire = mt_rand(10000000, 99999999);

            // Mettre à jour le code unique
            $codeUnique = $annee . $mois . $jour . '-' . $codeAleatoire;
        }



        $factures = $data['factures'];

        foreach ($factures as $factureData) {

            $validatedData = Validator::make($factureData, [
                'acte_medical_id' => 'nullable|integer',
                'patient_id' => 'required|integer',
                // 'user_id' => 'required|exists:users,id', // Remplacez "users" par le nom de la table où vous souhaitez vérifier l'existence de 'user_id', et "id" par le nom de la colonne correspondante
                // 'centre_id' => 'required',
                'code' => 'nullable|string',
                'autre' => 'nullable|string',
                'prix' => 'required|integer',
                'quantite' => 'required|integer',
                'montant' => 'required|integer',
            ])->validate();

            $facture = Facture::create([

                'is_synced' => 0, // Marquer comme non synchronisé
                'reference' => $codeUnique,
                'payement_id' => $payementId,
                'acte_medical_id' => $validatedData['acte_medical_id'],
                'patient_id' => $validatedData['patient_id'],
                'user_id' => $user->id,
                'centre_id' => $user->idcentre, // Récupérer l'id du centre à partir de la relation
                'code' => $validatedData['code'],
                'autre' => $validatedData['autre'],
                'prix' => $validatedData['prix'],
                'quantite' => $validatedData['quantite'],
                'montant' => $validatedData['montant'],
            ]);

            $factures[] = $facture;
        }

        return response()->json([
            'success' => true,
            'message' => 'Factures enregistrées avec succès.',
            'data' => $factures,
        ], 201);
    }


    // public function index()
    // {

    //     $user = auth()->user();
    //     $centreId = $user->idcentre;

    //     $factures = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
    //         ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
    //         ->join('patients', 'patients.id', '=', 'factures.patient_id')
    //         ->join('users', 'users.id', '=', 'factures.user_id')
    //         ->select('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name as nomUser', 'users.prenom as prenomUser', 'patients.nom', 'patients.prenom', 'mode_payements.mode as mode_payement', DB::raw('SUM(factures.montant) as total_montant'), 'factures.created_at')
    //         ->where('factures.centre_id', $centreId) // Ajoutez cette condition pour filtrer par centre_id
    //         ->groupBy('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name', 'users.prenom', 'patients.nom', 'patients.prenom', 'mode_payements.mode', 'factures.created_at')
    //         ->orderBy('factures.created_at', 'desc')
    //         ->get();

    //     return response()->json([
    //         'success' => true,
    //         'data' => $factures,
    //         'message' => 'Liste des factures récupérées avec succès.'
    //     ]);
    // }

    public function index()
    {

        $user = auth()->user();

        $centreId = $user->idcentre;
        $roleId = $user->role_id;



        $factures = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('patients', 'patients.id', '=', 'factures.patient_id')
            ->join('users', 'users.id', '=', 'factures.user_id')
            ->select('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name as nomUser', 'users.prenom as prenomUser', 'patients.nom', 'patients.prenom', 'mode_payements.mode as mode_payement', DB::raw('SUM(factures.montant) as total_montant'), 'factures.created_at')
            ->where('factures.centre_id', $centreId) // Ajoutez cette condition pour filtrer par centre_id
            ->groupBy('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name', 'users.prenom', 'patients.nom', 'patients.prenom', 'mode_payements.mode', 'factures.created_at')
            ->orderBy('factures.created_at', 'desc')
            ->get();


        if ($roleId == 10 || $roleId == 1) {


            $factures = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
                ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
                ->join('patients', 'patients.id', '=', 'factures.patient_id')
                ->join('users', 'users.id', '=', 'factures.user_id')
                ->select('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name as nomUser', 'users.prenom as prenomUser', 'patients.nom', 'patients.prenom', 'mode_payements.mode as mode_payement', DB::raw('SUM(factures.montant) as total_montant'), 'factures.created_at')
                // ->where('factures.centre_id', $centreId) // Ajoutez cette condition pour filtrer par centre_id
                ->groupBy('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name', 'users.prenom', 'patients.nom', 'patients.prenom', 'mode_payements.mode', 'factures.created_at')
                ->orderBy('factures.created_at', 'desc')
                ->get();
        }


        return response()->json([
            'success' => true,
            'data' => $factures,
            'message' => 'Liste des factures récupérées avec succès.'
        ]);
    }


    public function rapportGeneral()
    {
        $utilisateur = auth()->user();
        $centreId = $utilisateur->idcentre;
        $roleId = $utilisateur->role_id;

        $facturesQuery = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('patients', 'factures.patient_id', '=', 'patients.id')
            ->join('centresanitaires', 'factures.centre_id', '=', 'centresanitaires.id')
            ->join('departements', 'centresanitaires.departement_id', '=', 'departements.id')
            ->join('communes', 'centresanitaires.commune_id', '=', 'communes.id')
            ->join('arrondissements', 'centresanitaires.arrondissement_id', '=', 'arrondissements.id')
            ->join('quartiers', 'centresanitaires.quartier_id', '=', 'quartiers.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('users', 'users.id', '=', 'factures.user_id')

            ->select(
                'factures.reference',
                'payements.mode_payement_id',
                'factures.payement_id',
                'factures.patient_id',
                'users.name as nomUser',
                'users.prenom as prenomUser',
                'patients.nom',
                'patients.prenom',
                'departements.nom as nomDepartement',
                'communes.nom as nomCommunes',
                'arrondissements.nom as nomArrondissement',
                'quartiers.nom as nomQuartier',
                'mode_payements.mode as mode_payement',
                DB::raw('SUM(factures.montant) as total_montant'),
                'factures.created_at',


            )
            ->orderBy('factures.created_at', 'desc')
            ->groupBy(
                'factures.reference',
                'payements.mode_payement_id',
                'factures.payement_id',
                'factures.patient_id',
                'users.name',
                'users.prenom',
                'patients.nom',
                'patients.prenom',
                'departements.nom',
                'communes.nom',
                'arrondissements.nom',
                'quartiers.nom',
                'mode_payements.mode',
                'factures.created_at'
            );

        // Vérifie le rôle de l'utilisateur et filtre en conséquence
        if ($roleId != 10) {

            if ($roleId == 1 && $centreId === null) {
                // Utilisateur Admin sans centre associé
                // Ne pas appliquer de filtre sur le centre_id
            } else {
                $facturesQuery->where('factures.centre_id', $centreId);
            }
            // $facturesQuery->where('factures.centre_id', $centreId);
        }

        $factures = $facturesQuery->get();

        return response()->json([
            'success' => true,
            'data' => $factures,
            'message' => 'Liste des rapports généraux avec succès.'
        ]);
    }

    public function getAllMomos()
    {

        $DataMomo = Momo::all();

        return response()->json([
            'success' => true,
            'data' => $DataMomo,
            'message' => 'Liste des Transactions MOMO récupérées avec succès.'
        ]);
    }

    public function getAllEspece()
    {

        $data = Espece::all();

        return response()->json([
            'success' => true,
            'data' => $data,
            'message' => 'Liste des Transactions Espece récupérées avec succès.'
        ]);
    }



    public function getAllFedapay()
    {
        $DataFedpay = Fedapay::all();
        return response()->json([
            'success' => true,
            'data' => $DataFedpay,
            'message' => 'Liste des Transactions Fedapay récupérées avec succès.'
        ]);
    }

    public function show($id)
    {

        // recuperer toutes les details en fonction de l'id du payement à utiliser dlister les factures dans le tableau en fonction du payement

        $factureDetails = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('patients', 'patients.id', '=', 'factures.patient_id')
            ->join('centresanitaires', 'centresanitaires.id', '=', 'factures.centre_id')
            ->select('centresanitaires.nom as nom_centre', 'factures.reference', 'factures.payement_id', 'payements.mode_payement_id', 'factures.patient_id', 'factures.acte_medical_id', 'patients.nom', 'patients.prenom', 'factures.code', 'factures.autre', 'factures.prix', 'factures.quantite', 'factures.montant', 'factures.created_at', 'mode_payements.mode as mode_payement')
            ->where('factures.payement_id', $id)
            ->get();

        if ($factureDetails->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'Facture introuvable.'
            ]);
        }

        return response()->json([
            'success' => true,
            'data' => $factureDetails,
            'message' => 'Détails de la facture récupérés avec succès.'
        ]);
    }

    public function showFacture($id)
    {

        // recuperer toutes les details en fonction de l'id du payement

        $data = Facture::where('id', $id)->get();

        if ($data->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'Facture introuvable.'
            ]);
        }

        return response()->json([
            'success' => true,
            'data' =>  $data,
            'message' => 'Détails de la facture récupérés avec succès.'
        ]);
    }




    public function generateQrCode($invoiceId)
    {
        $invoiceUrl = route('factures.codeqr', ['id' => $invoiceId]);
        $qrCode = QrCode::size(50)->generate($invoiceUrl);

        return response()->json(['qrCode' => $qrCode, 'invoiceUrl' => $invoiceUrl]);
    }


    public function filtrer(Request $request)
    {
        $user = auth()->user();
        $centreId = $user->idcentre;
        $startDate = $request->input('date_debut');

        $endDate = $request->input('date_fin');

        // Vérifier si la date de départ est inférieure à la date de fin
        if ($startDate > $endDate) {
            return "La date de début doit être antérieure à la date de fin.";
        }

        $rapports = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('users', 'users.id', '=', 'factures.user_id')
            ->join('patients', 'patients.id', '=', 'factures.patient_id')
            ->where('factures.centre_id', $centreId) // Ajoutez cette condition pour filtrer par centre_id
            ->whereDate('factures.created_at', '>=', $startDate)
            ->whereDate('factures.created_at', '<=', $endDate)
            ->select('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name as nomUser', 'users.prenom as prenomUser', 'patients.nom', 'patients.prenom', 'mode_payements.mode as mode_payement', DB::raw('SUM(factures.montant) as total_montant'), 'factures.created_at')
            ->groupBy('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name', 'users.prenom', 'patients.nom', 'patients.prenom', 'mode_payements.mode', 'factures.created_at')
            ->orderBy('factures.created_at', 'desc')
            ->get();


        return response()->json(['data' => $rapports]);
    }


    function getTotalMontants()
    {
        $user = auth()->user();
        $centreId = $user->idcentre;

        $roleId = $user->role_id;

        $dateActuelle = Carbon::now()->toDateString();



        $totalFacture = DB::table('factures')
            ->whereDate('created_at', $dateActuelle)
            ->where('factures.centre_id', $centreId)
            ->sum('montant');

        $totalEncaissement = DB::table('encaissements')
            ->whereDate('created_at', $dateActuelle)
            ->where('encaissements.encaissement_centre_id', $centreId)
            ->sum('montant');

        if ($roleId == 10 || $roleId == 1) {

            $totalFacture = DB::table('factures')
                ->whereDate('created_at', $dateActuelle)
                ->sum('montant');

            $totalEncaissement = DB::table('encaissements')
                ->whereDate('created_at', $dateActuelle)
                ->sum('montant');
        }


        $totalMontants = $totalFacture + $totalEncaissement;
        //return $totalMontants ;
        return response()->json([
            'success' => true,
            'message' => 'La recette de la date actuelle est:',
            'data' => $totalMontants
        ]);
    }


    function getRecentFactures()
    {


        $user = auth()->user();
        $centreId = $user->idcentre;
        $roleId = $user->role_id;

        $recentFactures = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('patients', 'patients.id', '=', 'factures.patient_id')
            ->select('factures.reference', 'factures.payement_id as payement_id', 'patients.nom', 'patients.prenom', DB::raw('SUM(factures.montant) as total_montant'))
            ->where('factures.centre_id', $centreId) // Ajoutez cette condition pour filtrer par centre_id
            ->groupBy('factures.reference', 'factures.payement_id', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'patients.nom', 'patients.prenom', 'mode_payements.mode', 'factures.created_at')
            ->orderBy('factures.created_at', 'desc')
            ->take(5)
            ->get();

        if ($roleId == 10 || $roleId == 1) {

            $recentFactures = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
                ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
                ->join('patients', 'patients.id', '=', 'factures.patient_id')
                ->select('factures.reference', 'factures.payement_id as payement_id',  'patients.nom', 'patients.prenom', DB::raw('SUM(factures.montant) as total_montant'))
                // ->where('factures.centre_id', $centreId) // Ajoutez cette condition pour filtrer par centre_id
                ->groupBy('factures.reference', 'factures.payement_id', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'patients.nom', 'patients.prenom', 'mode_payements.mode', 'factures.created_at')
                ->orderBy('factures.created_at', 'desc')
                ->take(5)
                ->get();
        }




        // return $recentFactures;
        return response()->json([
            'success' => true,
            'message' => 'Les dix ventes les plus recentes:',
            'data' => $recentFactures

        ]);
    }

    function getCentre()
    {

        $user = auth()->user();
        $id =  $user->idcentre;
        $getCentre = CentreSanitaire::where('id', $id);

        return response()->json([
            'success' => true,
            'message' => 'liste des centres sanitaires en fonction de l\'id',
            'data' => $getCentre,

        ]);
    }


    //liste des payements journaliers efféctuées lorsqu'on choisi l'utilisateur

    function getUserCentre($caissierId)
    {
        $user = auth()->user();
        $idCentre = $user->idcentre;

        $rapports = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('patients', 'patients.id', '=', 'factures.patient_id')
            ->join('users', 'users.id', '=', 'factures.user_id')
            ->where('factures.centre_id', $idCentre)
            ->where('factures.user_id', $caissierId)
            ->whereDate('factures.created_at', '=', date('Y-m-d')) // Utilisation de la fonction date() pour obtenir la date actuelle au format Y-m-d
            ->select('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name as nomUser', 'users.prenom as prenomUser', 'patients.nom', 'patients.prenom', 'mode_payements.mode as mode_payement', DB::raw('SUM(factures.montant) as total_montant'), 'factures.created_at')
            ->groupBy('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name', 'users.prenom', 'patients.nom', 'patients.prenom', 'mode_payements.mode', 'factures.created_at')
            ->orderBy('factures.created_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Liste des centres sanitaires en fonction de l\'ID',
            'data' => $rapports
        ]);
    }


    public function getUserCentr($hopital)
    {
        $user = auth()->user();
        $idCentre = $user->idcentre;
        $roleId = $user->role_id;
        $rapports = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('users', 'factures.user_id', '=', 'users.id')
            ->join('patients', 'factures.patient_id', '=', 'patients.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->select('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name as nomUser', 'users.prenom as prenomUser', 'patients.nom', 'patients.prenom', 'mode_payements.mode as mode_payement', DB::raw('SUM(factures.montant) as total_montant'), 'factures.created_at')
            ->where('factures.centre_id', $hopital) // Filtre par l'identifiant de l'hôpital.
            // ->whereDate('factures.created_at', '=', now()->format('Y-m-d'))
            // ->when($user->hasRole('Super_admin'), function ($query) {
            //     // Si l'utilisateur est un superadmin, ignore le filtrage par centre et hôpital
            //     return $query;
            // }, function ($query) use ($idCentre, $hopital) {
            //     // Si ce n'est pas un superadmin, filtre par le centre de l'utilisateur
            //     // et l'hôpital actuel
            //     return $query->where('users.idcentre', $idCentre);
            // })
            ->when($roleId == 1 && $idCentre === null, function ($query) {
                // Si l'utilisateur est un Admin sans centre associé, ignore le filtrage par centre
                return $query;
            }, function ($query) use ($idCentre) {
                // Si ce n'est pas un Admin sans centre associé, filtre par le centre de l'utilisateur
                return $query->where('users.idcentre', $idCentre);
            })
            ->groupBy('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name', 'users.prenom', 'patients.nom', 'patients.prenom', 'mode_payements.mode', 'factures.created_at')
            ->orderBy('factures.created_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Liste des rapports par hôpital',
            'data' => $rapports
        ]);
    }

    public function getUserDeparte($departe)
    {
        $user = auth()->user();
        // Vérifiez si l'utilisateur a le rôle avec l'ID égal à 1
        if ($user->role_id == 1) {
            $idCentre = null; // Utilisateur sans centre
        } else {
            // Assurez-vous que l'utilisateur a un centre associé
            if (!$user->idcentre) {
                return response()->json([
                    'success' => false,
                    'message' => "L'utilisateur n'a pas de centre associé."
                ]);
            }

            $idCentre = $user->idcentre;
        }
        // $idCentre = $user->idcentre;


        $rapports = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('users', 'factures.user_id', '=', 'users.id')
            ->join('patients', 'factures.patient_id', '=', 'patients.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('centresanitaires', 'factures.centre_id', '=', 'centresanitaires.id')
            // ->join('centresanitaires', 'factures.centre_id', '=', 'centresanitaires.id')
            ->join('departements', 'centresanitaires.departement_id', '=', 'departements.id')
            ->join('communes', 'centresanitaires.commune_id', '=', 'communes.id')
            ->join('arrondissements', 'centresanitaires.arrondissement_id', '=', 'arrondissements.id')
            ->join('quartiers', 'centresanitaires.quartier_id', '=', 'quartiers.id')
            ->select(
                'factures.reference',
                'payements.mode_payement_id',
                'factures.payement_id',
                'factures.patient_id',
                'users.name as nomUser',
                'users.prenom as prenomUser',
                'departements.nom as nomDepartement',
                'communes.nom as nomCommunes',
                'quartiers.nom as nomQuartier',
                'arrondissements.nom as nomArrondissement',
                'patients.nom',
                'patients.prenom',
                'mode_payements.mode as mode_payement',
                DB::raw('SUM(factures.montant) as total_montant'),
                'factures.created_at'
            )
            ->when($idCentre !== null, function ($query) use ($idCentre) {
                $query->where('factures.centre_id', $idCentre);
            })
            ->when($departe !== null, function ($query) use ($departe) {
                $query->where('centresanitaires.departement_id', $departe);
            })
            // ->where('factures.centre_id', $idCentre)
            // ->where('centresanitaires.departement_id', $departe)
            // ->where('patients.departement_id', $departe) // Assurez-vous que le nom de la colonne est correct
            ->orderBy('factures.created_at', 'desc')
            ->groupBy(
                'factures.reference',
                'payements.mode_payement_id',
                'factures.payement_id',
                'factures.patient_id',
                'users.name',
                'users.prenom',
                'patients.nom',
                'patients.prenom',
                'departements.nom',
                'communes.nom',
                'quartiers.nom',
                'arrondissements.nom',
                'mode_payements.mode',
                'factures.created_at'
            )->get();


        return response()->json([
            'success' => true,
            'message' => 'Liste des rapports par département',
            'data' => $rapports
        ]);
    }

    public function getUserCom($com)
    {
        $user = auth()->user();
        // Vérifiez si l'utilisateur a le rôle avec l'ID égal à 1
        if ($user->role_id == 1) {
            $idCentre = null; // Utilisateur sans centre
        } else {
            // Assurez-vous que l'utilisateur a un centre associé
            if (!$user->idcentre) {
                return response()->json([
                    'success' => false,
                    'message' => "L'utilisateur n'a pas de centre associé."
                ]);
            }

            $idCentre = $user->idcentre;
        }
        // $idCentre = $user->idcentre;


        $rapports = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('users', 'factures.user_id', '=', 'users.id')
            ->join('patients', 'factures.patient_id', '=', 'patients.id')
            ->join('centresanitaires', 'factures.centre_id', '=', 'centresanitaires.id')
            ->join('communes', 'centresanitaires.commune_id', '=', 'communes.id')
            ->join('quartiers', 'centresanitaires.quartier_id', '=', 'quartiers.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('departements', 'centresanitaires.departement_id', '=', 'departements.id')
            ->join('arrondissements', 'centresanitaires.arrondissement_id', '=', 'arrondissements.id')
            // ->join('centresanitaires', 'factures.centre_id', '=', 'centresanitaires.id')
            ->select('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'departements.nom as nomDepartement', 'quartiers.nom as nomQuartier', 'arrondissements.nom as nomArrondissement', 'factures.patient_id', 'users.name as nomUser', 'users.prenom as prenomUser', 'patients.nom', 'patients.prenom', 'communes.nom as nomCommunes', 'mode_payements.mode as mode_payement', DB::raw('SUM(factures.montant) as total_montant'), 'factures.created_at')
            ->when($idCentre !== null, function ($query) use ($idCentre) {
                $query->where('factures.centre_id', $idCentre);
            })
            ->when($com !== null, function ($query) use ($com) {
                $query->where('centresanitaires.commune_id', $com);
            })
            // ->where('factures.centre_id', $idCentre)
            // ->where('centresanitaires.commune_id', $com)
            // ->where('patients.commune_id', $com) // Assurez-vous que le nom de la colonne est correct
            ->orderBy('factures.created_at', 'desc')
            ->groupBy('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'arrondissements.nom', 'quartiers.nom', 'users.name', 'users.prenom', 'patients.nom', 'patients.prenom', 'communes.nom', 'departements.nom', 'mode_payements.mode', 'factures.created_at')
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Liste des rapports par commune',
            'data' => $rapports
        ]);
    }


    public function getUserAron($aron)
    {
        $user = auth()->user();
        // Vérifiez si l'utilisateur a le rôle avec l'ID égal à 1
        if ($user->role_id == 1) {
            $idCentre = null; // Utilisateur sans centre
        } else {
            // Assurez-vous que l'utilisateur a un centre associé
            if (!$user->idcentre) {
                return response()->json([
                    'success' => false,
                    'message' => "L'utilisateur n'a pas de centre associé."
                ]);
            }

            $idCentre = $user->idcentre;
        }
        // $idCentre = $user->idcentre;

        $rapports = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('users', 'factures.user_id', '=', 'users.id')
            ->join('patients', 'factures.patient_id', '=', 'patients.id')
            ->join('centresanitaires', 'factures.centre_id', '=', 'centresanitaires.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('departements', 'centresanitaires.departement_id', '=', 'departements.id')
            ->join('communes', 'centresanitaires.commune_id', '=', 'communes.id')
            ->join('arrondissements', 'centresanitaires.arrondissement_id', '=', 'arrondissements.id')
            ->join('quartiers', 'centresanitaires.quartier_id', '=', 'quartiers.id')
            ->select(
                'factures.reference',
                'payements.mode_payement_id',
                'factures.payement_id',
                'communes.nom as nomCommunes',
                'quartiers.nom as nomQuartier',
                'departements.nom as nomDepartement',
                'arrondissements.nom as nomArrondissement',
                'factures.patient_id',
                'users.name as nomUser',
                'users.prenom as prenomUser',
                'patients.nom',
                'patients.prenom',
                'mode_payements.mode as mode_payement',
                DB::raw('SUM(factures.montant) as total_montant'),
                'factures.created_at'
            )
            ->when($idCentre !== null, function ($query) use ($idCentre) {
                $query->where('factures.centre_id', $idCentre);
            })
            ->when($aron !== null, function ($query) use ($aron) {
                $query->where('centresanitaires.arrondissement_id', $aron);
            })
            // ->where('factures.centre_id', $idCentre)
            // ->where('centresanitaires.arrondissement_id', $aron)
            // ->where('patients.arrondissement_id', $aron) // Assurez-vous que le nom de la colonne est correct
            ->orderBy('factures.created_at', 'desc')
            ->groupBy(
                'factures.reference',
                'payements.mode_payement_id',
                'factures.payement_id',
                'arrondissements.nom',
                'communes.nom',
                'quartiers.nom',
                'departements.nom',
                'factures.patient_id',
                'users.name',
                'users.prenom',
                'patients.nom',
                'patients.prenom',
                'mode_payements.mode',
                'factures.created_at'
            )
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Liste des rapports par arrondissement',
            'data' => $rapports
        ]);
    }

    public function getUserQua($quart)
    {
        $user = auth()->user();
        // Vérifiez si l'utilisateur a le rôle avec l'ID égal à 1
        if ($user->role_id == 1) {
            $idCentre = null; // Utilisateur sans centre
        } else {
            // Assurez-vous que l'utilisateur a un centre associé
            if (!$user->idcentre) {
                return response()->json([
                    'success' => false,
                    'message' => "L'utilisateur n'a pas de centre associé."
                ]);
            }

            $idCentre = $user->idcentre;
        }
        // $idCentre = $user->idcentre;

        $rapports = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('users', 'factures.user_id', '=', 'users.id')
            ->join('patients', 'factures.patient_id', '=', 'patients.id')
            ->join('centresanitaires', 'factures.centre_id', '=', 'centresanitaires.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('departements', 'centresanitaires.departement_id', '=', 'departements.id')
            ->join('communes', 'centresanitaires.commune_id', '=', 'communes.id')
            ->join('arrondissements', 'centresanitaires.arrondissement_id', '=', 'arrondissements.id')
            ->join('quartiers', 'centresanitaires.quartier_id', '=', 'quartiers.id')
            ->select(
                'factures.reference',
                'payements.mode_payement_id',
                'factures.payement_id',
                'communes.nom as nomCommunes',
                'quartiers.nom as nomQuartier',
                'departements.nom as nomDepartement',
                'arrondissements.nom as nomArrondissement',
                'factures.patient_id',
                'users.name as nomUser',
                'users.prenom as prenomUser',
                'patients.nom',
                'patients.prenom',
                'mode_payements.mode as mode_payement',
                DB::raw('SUM(factures.montant) as total_montant'),
                'factures.created_at'
            )->when($idCentre !== null, function ($query) use ($idCentre) {
                $query->where('factures.centre_id', $idCentre);
            })
            ->when($quart !== null, function ($query) use ($quart) {
                $query->where('centresanitaires.quartier_id', $quart);
            })
            // ->where('factures.centre_id', $idCentre)
            // ->where('centresanitaires.quartier_id', $quart)
            // ->where('patients.quartier_id', $quart) // Assurez-vous que le nom de la colonne est correct
            ->orderBy('factures.created_at', 'desc')
            ->groupBy(
                'factures.reference',
                'payements.mode_payement_id',
                'arrondissements.nom',
                'communes.nom',
                'quartiers.nom',
                'departements.nom',
                'factures.payement_id',
                'factures.patient_id',
                'users.name',
                'users.prenom',
                'patients.nom',
                'patients.prenom',
                'mode_payements.mode',
                'factures.created_at'
            )
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Liste des rapports par quartier',
            'data' => $rapports
        ]);
    }


    //liste des payements journaliers efféctuées
    public function getFacturesToday()
    {
        $user = auth()->user();

        $centreId = $user->idcentre;

        $getCaissiers = User::where('idcentre', $centreId)->where('role_id', 4) // Filtre les utilisateurs caissier ayant le rôle avec ID 4 (caissier)
            ->get();

        // dd($getCaissiers);

        $rapports = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('patients', 'patients.id', '=', 'factures.patient_id')
            ->join('users', 'users.id', '=', 'factures.user_id')
            ->where('factures.centre_id', $centreId)
            ->whereDate('factures.created_at', '=', date('Y-m-d')) // Utilisation de la fonction date() pour obtenir la date actuelle au format Y-m-d
            ->select('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name as nomUser', 'users.prenom as prenomUser', 'patients.nom', 'patients.prenom', 'mode_payements.mode as mode_payement', DB::raw('SUM(factures.montant) as total_montant'), 'factures.created_at')
            ->groupBy('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name', 'users.prenom', 'patients.nom', 'patients.prenom', 'mode_payements.mode', 'factures.created_at')
            ->orderBy('factures.created_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'liste des factures de ce jour et la list des caissiers de l\'hopital',
            'data' =>  [
                'caissiers' => $getCaissiers,
                'rapports' => $rapports,
            ],

        ]);
    }




    //liste des payements journaliers efféctuées


    public function getFacturesTerminalToday()
    {
        $user = auth()->user();

        $centreId = $user->idcentre;

        $getTerminal = Terminal::where('idcentre', $centreId)->get(); // Filtre les terminaux par centre


        // dd($getCaissiers);

        $rapports = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('patients', 'patients.id', '=', 'factures.patient_id')
            ->join('users', 'users.id', '=', 'factures.user_id')
            ->where('factures.centre_id', $centreId)
            ->whereDate('factures.created_at', '=', date('Y-m-d')) // Utilisation de la fonction date() pour obtenir la date actuelle au format Y-m-d
            ->select('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name as nomUser', 'users.prenom as prenomUser', 'patients.nom', 'patients.prenom', 'mode_payements.mode as mode_payement', DB::raw('SUM(factures.montant) as total_montant'), 'factures.created_at')
            ->groupBy('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name', 'users.prenom', 'patients.nom', 'patients.prenom', 'mode_payements.mode', 'factures.created_at')
            ->orderBy('factures.created_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'liste des factures de ce jour et la list des caissiers de l\'hopital',
            'data' =>  [
                'terminals' => $getTerminal,
                'rapports' => $rapports,
            ],

        ]);
    }


    //liste des payements journaliers efféctuées lorsqu'on choisi un terminal

    function getFactureTerminal($terminalId)
    {
        $user = auth()->user();
        $idCentre = $user->idcentre;


        $rapports = Facture::join('payements', 'factures.payement_id', '=', 'payements.id')
            ->join('mode_payements', 'payements.mode_payement_id', '=', 'mode_payements.id')
            ->join('patients', 'patients.id', '=', 'factures.patient_id')
            ->join('users', 'users.id', '=', 'factures.user_id')
            ->join('affecter_terminal', 'users.id', '=', 'affecter_terminal.user_id')
            ->where('factures.centre_id', $idCentre)
            ->where('affecter_terminal.terminal_id', $terminalId)
            ->whereDate('factures.created_at', '=', date('Y-m-d')) // Utilisation de la fonction date() pour obtenir la date actuelle au format Y-m-d
            ->select('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name as nomUser', 'users.prenom as prenomUser', 'patients.nom', 'patients.prenom', 'mode_payements.mode as mode_payement', DB::raw('SUM(factures.montant) as total_montant'), 'factures.created_at')
            ->groupBy('factures.reference', 'payements.mode_payement_id', 'factures.payement_id', 'factures.patient_id', 'users.name', 'users.prenom', 'patients.nom', 'patients.prenom', 'mode_payements.mode', 'factures.created_at')
            ->orderBy('factures.created_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Liste des centres sanitaires en fonction de l\'ID',
            'data' => $rapports
        ]);
    }



    public function getEspece($id)
    {


        $data = Espece::where('id', $id)->get();

        if ($data->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'Facture introuvable.'
            ]);
        }

        return response()->json([
            'success' => true,
            'data' =>  $data,
            'message' => 'Détails de la facture récupérés avec succès.'
        ]);
    }



    public function storeFacture(Request $request)
    {

        // recuperer toutes les details en fonction de l'id du payement
        $validatedData =  $request->validate([
            'acte_medical_id' => 'nullable|integer',
            'patient_id' => 'required|integer',
            'code' => 'nullable|string',
            'autre' => 'nullable|string',
            'prix' => 'required|integer',
            'quantite' => 'required|integer',
            'montant' => 'required|integer',
        ]);

        $data = Facture::create([

            'is_synced' => 0, // Marquer comme non synchronisé
            'reference' => $request->reference,
            'payement_id' => $request->payement_id,
            'acte_medical_id' => $validatedData['acte_medical_id'],
            'patient_id' => $validatedData['patient_id'],
            'user_id' =>  $request->user_id,
            'centre_id' => $request->centre_id, // Récupérer l'id du centre à partir de la relation
            'code' => $validatedData['code'],
            'autre' => $validatedData['autre'],
            'prix' => $validatedData['prix'],
            'quantite' => $validatedData['quantite'],
            'montant' => $validatedData['montant'],
        ]);

        // Réponse JSON avec les données du nouveau paiement
        return response()->json([
            'success' => true,
            'data' => $data,
            'message' => 'Paiement créé avec succès.'
        ], 201);
    }


    public function synchroniserFactures()
    {

        // Récupérer l'utilisateur authentifié

        $accessToken = config('app.API_ACCESS_TOKEN');

        $url = 'http://www.google.com';

        $timeout = 5;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Vérifier le statut de la connexion Internet

        if ($httpCode == 200) {

            // $payementsNonSync = payement::where('is_synced', 0)->get();

            $facturesNonSync = Facture::where('is_synced', 0)->get();

            $headers = [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $accessToken,
            ];


            foreach ($facturesNonSync as $facture) {


                $response =  Http::withHeaders($headers)->get('https://api-medpay.akasigroup.net/api/showfacture/' . $facture->id); // l'id de la facture

                if (!$response->successful()) {

                    $data = $facture->toArray();

                    $response = Http::withHeaders($headers)->post('https://api-medpay.akasigroup.net/api/storefacture', $data);

                    Log::info('Eneregistrement effectué ');
                }


                if ($response->successful()) {

                    // Mettre à jour le statut de synchronisation du payement en local
                    $facture->is_synced = 1;
                    $facture->save();
                    Log::info('facture synchronisé avec succès. id : ' . $facture->id);
                } else {

                    Log::error('Erreur lors de la synchronisation de l\'facture. id : ' . $facture->id . ' - Réponse API : ' . json_encode($response->json()));
                }
            }
        } else {
            Log::error('Internet connection is not available.');
        }
    }
}
