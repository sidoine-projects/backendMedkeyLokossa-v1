<?php

namespace App\Http\Controllers;

use App\Models\ModePayement;
use Illuminate\Http\Request;

class ModePayementController extends Controller
{
    /**
     * Display a listing of the resource.
     */


    public function index()
    {
        $modePayements = ModePayement::all();

        return response()->json([
            'success' => true,
            'data' => $modePayements,
            'message' => 'Liste des modes de paiement.'
        ]);
    }


    /**
     * Store a newly created resource in storage.
     */
    // public function store(Request $request)
    // {
    //     $request->validate([
    //         'nom' => 'required|string|max:255',
    //         'pays_id' => 'required|exists:pays,id',
    //         // Ajoutez d'autres règles de validation pour les autres champs si nécessaire
    //     ]);

    //     $modePayement = new ModePayement();
    //     $modePayement->nom = $request->input('nom');
    //     $modePayement->pays_id = $request->input('pays_id');

    //     // Enregistrez le département dans la base de données
    //     $modePayement->save();

    //     return response()->json([
    //         'success' => true,
    //         'data' => $modePayement,
    //         'message' => 'Le département a été créé avec succès.'
    //     ]);
    // }
    /**
     * Display the specified resource.
     */
    


    public function show($id)
    {
        $modePayement = ModePayement::find($id);

        return response()->json([
            'success' => true,
            'data' => $modePayement,
            'message' => 'Informations sur le mode de paiement récupérées avec succès.'
        ]);
    }


    /**
     * Update the specified resource in storage.
     */
    // public function update(Request $request, $id)
    // {
    //     $request->validate([
    //         'nom' => 'required|string|max:255',
    //         'pays_id' => 'required|exists:pays,id',
    //         // Ajoutez d'autres règles de validation pour les autres champs si nécessaire
    //     ]);

    //     $modePayement =ModePayement::find($id);
    //     $modePayement->nom = $request->input('nom');

    //     // Mettez à jour les autres champs du département si nécessaire

    //     // Enregistrez les modifications dans la base de données
    //     $modePayement->save();

    //     return response()->json([
    //         'success' => true,
    //         'data' => $modePayement,
    //         'message' => 'Le département a été mis à jour avec succès.'
    //     ]);
    // }


    /**
     * Remove the specified resource from storage.
     */
    // public function destroy($id)
    // {
    //     $modePayement =ModePayement::find($id);

    //     // Supprimez le département de la base de données
    //     $modePayement->delete();

    //     return response()->json([
    //         'success' => true,
    //         'message' => 'Le département a été supprimé avec succès.'
    //     ]);
    // }
}